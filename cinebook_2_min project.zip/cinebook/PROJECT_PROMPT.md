# CineBook: Full-Stack Movie Ticket Booking Application
## Complete Implementation Guide

---

## 📋 Project Overview
**CineBook** is a production-ready Full-Stack Movie Ticket Booking platform built with Python Flask, MongoDB, and vanilla HTML/CSS/JavaScript. The application features user and admin dashboards, interactive seat selection, Stripe payment integration, and asynchronous email notifications.

**Tech Stack:**
- **Frontend:** HTML5, CSS3, Vanilla JavaScript (ES6+)
- **Backend:** Python Flask
- **Database:** MongoDB with Mongoose-like ODM patterns
- **Authentication:** Flask-Bcrypt + Session management
- **Payments:** Stripe API (Sandbox)
- **Email:** SMTP (Gmail/Custom)
- **Hosting:** Render/Railway (Backend), Vercel (Frontend)

---

## 🏗️ Project Architecture

### Folder Structure (Target)
```
cinebook/
├── app.py                          # Main Flask application
├── config.py                       # Configuration & environment variables
├── requirements.txt                # Python dependencies
├── .env                            # Environment variables (Git ignored)
├── .gitignore
├── README.md
│
├── app/
│   ├── __init__.py
│   ├── models.py                   # Database schemas/models
│   ├── utils.py                    # Helper functions
│   ├── auth.py                     # Authentication routes
│   ├── movies.py                   # Movie-related routes
│   ├── bookings.py                 # Booking routes
│   ├── payments.py                 # Stripe payment routes
│   ├── admin.py                    # Admin dashboard routes
│   ├── emails.py                   # Email notification logic
│   └── background_jobs.py          # Async background tasks
│
├── static/
│   ├── css/
│   │   ├── style.css               # Global styles
│   │   ├── responsive.css          # Media queries
│   │   ├── components.css          # Reusable components
│   │   └── animations.css          # Transitions & animations
│   ├── js/
│   │   ├── app.js                  # Main app logic
│   │   ├── auth.js                 # Authentication logic
│   │   ├── bookings.js             # Booking engine logic
│   │   ├── seat-selector.js        # Interactive seat selection
│   │   ├── stripe-handler.js       # Stripe integration
│   │   ├── api.js                  # API client wrapper
│   │   └── utils.js                # Utility functions
│   ├── images/
│   │   ├── logo.png
│   │   ├── placeholder.png
│   │   └── icons/
│   └── data/
│       └── mock-data.js            # Frontend mock data
│
├── templates/
│   ├── base.html                   # Base template with navbar/footer
│   ├── index.html                  # Homepage
│   ├── movies.html                 # Movies catalog
│   ├── movie-details.html          # Movie details page
│   ├── favorites.html              # User favorites
│   ├── booking.html                # Booking page (seat selection + checkout)
│   ├── checkout-confirmation.html  # Order confirmation
│   ├── my-bookings.html            # User booking history
│   ├── auth/
│   │   ├── login.html
│   │   └── register.html
│   ├── admin/
│   │   ├── dashboard.html
│   │   ├── manage-shows.html
│   │   ├── manage-movies.html
│   │   └── analytics.html
│   └── errors/
│       ├── 404.html
│       └── 500.html
│
└── docs/
    ├── API_DOCUMENTATION.md        # Complete API reference
    ├── DATABASE_SCHEMA.md          # MongoDB collections schema
    └── DEPLOYMENT.md               # Deployment instructions

```

---

## 🗄️ Database Schema (MongoDB)

### Collections to Create:

#### 1. **users**
```json
{
  "_id": ObjectId,
  "name": String,
  "email": String,
  "phone": String,
  "password": String (hashed),
  "is_admin": Boolean,
  "favorites": [String],           // Array of movie IDs
  "total_bookings": Number,
  "total_spent": Number,
  "created_at": DateTime,
  "updated_at": DateTime
}
```

#### 2. **movies**
```json
{
  "_id": ObjectId,
  "title": String,
  "genre": String,
  "rating": Number,
  "duration": String,
  "language": String,
  "votes": Number,
  "image": String (URL),
  "banner": String (URL),
  "cast": [String],
  "director": String,
  "description": String,
  "price": {
    "2D": Number,
    "3D": Number,
    "4DX": Number
  },
  "tags": [String],
  "is_active": Boolean,
  "created_at": DateTime
}
```

#### 3. **theaters**
```json
{
  "_id": ObjectId,
  "name": String,
  "city": String,
  "address": String,
  "facilities": [String],
  "screens": [ObjectId],           // References to screens
  "created_at": DateTime
}
```

#### 4. **screens**
```json
{
  "_id": ObjectId,
  "theater_id": ObjectId,          // Foreign key to theater
  "name": String,                  // e.g., "Screen 1", "IMAX"
  "rows": Number,                  // Number of seat rows
  "columns": Number,               // Seats per row
  "total_seats": Number,
  "created_at": DateTime
}
```

#### 5. **shows**
```json
{
  "_id": ObjectId,
  "movie_id": ObjectId,            // Foreign key to movie
  "screen_id": ObjectId,           // Foreign key to screen
  "theater_id": ObjectId,
  "show_date": Date,
  "show_time": String,             // e.g., "14:30", "18:45"
  "format": String,                // "2D", "3D", "4DX"
  "ticket_price": Number,
  "available_seats": Number,
  "booked_seats": [ObjectId],      // Array of seat IDs
  "status": String,                // "active", "cancelled", "completed"
  "created_at": DateTime,
  "updated_at": DateTime
}
```

#### 6. **seats**
```json
{
  "_id": ObjectId,
  "show_id": ObjectId,             // Foreign key to show
  "row": String,                   // "A", "B", "C"...
  "column": Number,
  "seat_number": String,           // "A1", "A2", etc.
  "seat_type": String,             // "normal", "premium", "wheelchair"
  "status": String,                // "available", "booked", "reserved"
  "booked_by": ObjectId,           // User ID if booked
  "created_at": DateTime
}
```

#### 7. **bookings**
```json
{
  "_id": ObjectId,
  "user_id": ObjectId,             // Foreign key to user
  "movie_id": ObjectId,
  "show_id": ObjectId,
  "theater_id": ObjectId,
  "seat_ids": [ObjectId],          // Array of seat IDs
  "total_amount": Number,
  "booking_date": DateTime,
  "show_date": Date,
  "show_time": String,
  "payment_status": String,        // "pending", "completed", "failed", "refunded"
  "payment_method": String,        // "stripe", "cash_at_counter"
  "stripe_payment_id": String,
  "booking_status": String,        // "active", "cancelled", "completed"
  "qr_code": String,               // QR code for entry
  "email_sent": Boolean,
  "reminder_sent": Boolean,
  "cancellation_fee": Number,
  "cancelled_at": DateTime,
  "created_at": DateTime,
  "updated_at": DateTime
}
```

#### 8. **transactions**
```json
{
  "_id": ObjectId,
  "user_id": ObjectId,
  "booking_id": ObjectId,
  "amount": Number,
  "currency": String,              // "INR", "USD"
  "payment_method": String,
  "stripe_transaction_id": String,
  "status": String,                // "success", "failed", "pending"
  "error_message": String,
  "created_at": DateTime
}
```

---

## 🔌 Backend API Endpoints

### Authentication Routes

```
POST   /api/auth/register              → Register new user
POST   /api/auth/login                 → User login
POST   /api/auth/logout                → User logout
GET    /api/auth/profile               → Get current user profile
PUT    /api/auth/profile               → Update user profile
POST   /api/auth/check-session         → Verify active session
```

### Movie Routes

```
GET    /api/movies                     → Get all movies (with filters)
GET    /api/movies/:id                 → Get movie details
GET    /api/movies/:id/shows           → Get shows for a movie by date
POST   /api/movies/:id/favorite        → Toggle favorite (Auth required)
GET    /api/favorites                  → Get user's favorite movies (Auth required)
```

### Show & Booking Routes

```
GET    /api/shows/:show_id             → Get show details + available seats
GET    /api/seats/:show_id             → Get seat layout for a show
POST   /api/bookings/reserve           → Reserve seats (temporary hold)
DELETE /api/bookings/reserve/:id       → Cancel seat reservation
```

### Payment Routes

```
POST   /api/payments/create-intent     → Create Stripe payment intent
POST   /api/payments/confirm           → Confirm payment & create booking
GET    /api/bookings/:booking_id       → Get booking confirmation
```

### User Bookings Routes

```
GET    /api/my-bookings                → Get user's all bookings (Auth required)
GET    /api/my-bookings/:booking_id    → Get specific booking details
POST   /api/my-bookings/:booking_id/cancel → Cancel booking (Auth required)
GET    /api/my-bookings/:booking_id/download-ticket → Download ticket PDF
```

### Admin Routes

```
POST   /api/admin/movies               → Create new movie
PUT    /api/admin/movies/:id           → Edit movie details
DELETE /api/admin/movies/:id           → Delete movie
POST   /api/admin/shows                → Create new show
PUT    /api/admin/shows/:id            → Edit show
DELETE /api/admin/shows/:id            → Cancel show
GET    /api/admin/analytics            → Get sales analytics
GET    /api/admin/users                → Get all users
```

---

## 🎨 Frontend Features (Priority Order)

### Phase 1: Core Booking Flow (MVP)

#### 1. **Homepage** (`index.html`)
- Navigation header with logo, search, profile menu
- Banner carousel (featured movies/upcoming)
- "Now Showing" grid (6-8 movie cards)
- Movie cards showing: poster, title, rating, genre, tags
- Quick action buttons: "Book Now", "Trailer", "Add to Favorites"
- Footer with links, contact, social media

#### 2. **Movies Catalog Page** (`movies.html`)
- Grid layout of all movies
- Filter sidebar: Genre, Language, Rating, Price Range
- Search bar for movie titles
- Movie card component with hover effects
- "Load More" pagination or infinite scroll

#### 3. **Movie Details Page** (`movie-details.html`)
- High-res poster and banner images
- Movie information: Title, Genre, Director, Cast, Duration, Language
- Rating and votes display
- Description/synopsis
- **Date Selector:** Interactive calendar to select show date
- **Show Timings Grid:** Displays available showtimes for selected date with format (2D/3D/4DX)
- "Select Seats" button linking to booking page

#### 4. **Booking Page - Seat Selection** (`booking.html`)
- Theater selection (if multiple screens)
- **Interactive Seat Layout:**
  - Visual grid matrix of seats
  - Seat types: Normal (gray), Premium (gold), Wheelchair (blue), VIP (red)
  - Status indicators: Available (clickable), Booked (disabled), Selected (green)
  - Real-time seat count and price calculation
  - Multi-seat selection with visual feedback
  - Max seat selection limit (e.g., 10 seats per booking)
- **Legend:** Color-coded seat types with pricing
- Selected seats summary with total price
- "Proceed to Checkout" button

#### 5. **Payment/Checkout** (Stripe Integration)
- Order summary panel:
  - Movie name, date, time, theater
  - Selected seats, prices breakdown
  - Total amount
- **Stripe Elements Integration:**
  - Card number field, expiry, CVC
  - Cardholder name, email
  - Billing address (optional)
  - Terms & conditions checkbox
- "Pay Now" button → Handle payment via Stripe API
- Loading state during payment processing

#### 6. **Checkout Confirmation** (`checkout-confirmation.html`)
- Success message with booking ID
- Complete booking details:
  - QR Code for ticket entry
  - Movie information
  - Show date/time/theater
  - Seat numbers
  - Total amount paid
- Transaction ID
- "Download Ticket" button (PDF)
- "View My Bookings" link
- "Book Another Movie" button

#### 7. **Favorites Page** (`favorites.html`)
- Grid of favorited movies (Auth required)
- Remove from favorites button per movie
- Quick "Book Now" action
- Empty state message if no favorites

#### 8. **My Bookings Dashboard** (`my-bookings.html`, Auth required)
- Table/Card view of all user bookings with:
  - Movie name, poster thumbnail
  - Show date, time, theater
  - Booked seats
  - Booking status (Upcoming, Completed, Cancelled)
  - Amount paid
  - Actions: View Details, Download Ticket, Cancel (if eligible)
- Filter by status: Upcoming, Past, Cancelled
- Search by movie name or booking ID
- Booking detail modal with full information

---

### Phase 2: Authentication & User Management

#### 1. **Registration Page** (`auth/register.html`)
- Form fields:
  - Full Name
  - Email
  - Phone Number
  - Password (with strength indicator)
  - Confirm Password
- Email validation
- Phone validation (10 digits)
- Password strength requirements
- "Register" button
- Link to login page

#### 2. **Login Page** (`auth/login.html`)
- Email/Phone input
- Password input
- "Remember Me" checkbox
- "Forgot Password" link (Future phase)
- "Login" button
- Social login placeholders (Google - Future phase)
- Link to registration page

#### 3. **User Profile** (Modal/Page)
- View current profile
- Edit name, phone, email
- View booking statistics
- Account settings (password change)
- Logout button

---

### Phase 3: Admin Dashboard

#### Admin Layout Template
- Sidebar navigation (hidden on mobile)
- Header with admin name, notifications, logout
- Main content area
- Hide consumer navbar/footer in admin context

#### Pages:

1. **Admin Dashboard** (`admin/dashboard.html`)
   - Key metrics cards:
     - Total bookings today
     - Revenue today
     - Active shows
     - Total users
   - Charts:
     - Revenue trend (Line chart)
     - Bookings by movie (Bar chart)
     - Occupancy rate (Pie chart)
   - Recent bookings table

2. **Manage Movies** (`admin/manage-movies.html`)
   - Table of all movies
   - Add Movie button → Form modal
   - Edit button (inline edit or form modal)
   - Delete button with confirmation
   - Movie form fields:
     - Title, Genre, Director, Cast, Duration, Language
     - Image URL, Banner URL
     - Description
     - Price (2D, 3D, 4DX)
     - Tags, Active status

3. **Manage Shows** (`admin/manage-shows.html`)
   - Table of shows with filters:
     - Filter by movie, date, status
   - Add Show button → Form modal
   - Show form:
     - Movie (dropdown)
     - Theater/Screen (dropdown)
     - Date, Time, Format (2D/3D/4DX)
     - Ticket price
   - Edit show details
   - Cancel show (update status)
   - View seat availability per show

4. **Analytics Dashboard** (`admin/analytics.html`)
   - Date range selector (Last 7 days, 30 days, custom)
   - Key metrics:
     - Total revenue
     - Total bookings
     - Average booking value
     - Occupancy rate
   - Charts:
     - Revenue trends
     - Popular movies
     - Theater performance
     - Payment methods breakdown
   - Export reports button (CSV/PDF)

---

## 🔐 Authentication & Authorization

### User Types:
1. **Customer:** Can browse, book, view favorites, manage bookings
2. **Admin:** Can manage movies, shows, view analytics
3. **Guest:** Can view movies/shows but cannot book without logging in

### Session Management:
- Flask sessions with secure cookie storage
- Session timeout: 7 days (remember me), 1 hour (standard)
- Multi-session protection (prevent concurrent login abuse)

---

## 💳 Payment Integration (Stripe)

### Workflow:
1. User selects seats and clicks "Checkout"
2. Frontend creates Stripe Payment Intent via backend API
3. Stripe Elements form displayed for card entry
4. User enters card details
5. Frontend confirms payment with Stripe
6. Stripe returns success/failure
7. Backend:
   - Creates booking record on success
   - Marks seats as booked
   - Sends confirmation email
   - Returns booking ID + QR code

### Error Handling:
- Card declined → Display error, allow retry
- Insufficient funds → Specific error message
- Timeout → Queue for retry
- Duplicate prevention → Idempotency keys

---

## 📧 Email Notifications (Asynchronous)

### Scheduled Email Tasks:

#### 1. **Booking Confirmation** (Immediate)
- Trigger: Payment successful
- Content:
  - Booking ID, QR code
  - Movie, date, time, seats
  - Total amount, transaction ID
  - Download ticket link

#### 2. **Show Reminder** (8 hours before show)
- Trigger: Cron job checks bookings
- Content:
  - Show starts in 8 hours
  - Quick recap: Movie, time, theater, seats
  - Reminder to arrive 15 min early

#### 3. **New Show Alert** (Broadcast, when admin creates show)
- Trigger: Admin creates new show
- Recipients: All registered users (filtered by preferences - optional)
- Content:
  - New movie/show added
  - Movie details, showtimes
  - "Book Now" link

#### 4. **Cancellation Confirmation** (Immediate when user cancels)
- Trigger: User cancels booking
- Content:
  - Cancellation confirmation
  - Refund details
  - Cancellation fee (if applicable)
  - Refund timeline

#### 5. **Upcoming Cancellation Notice** (24 hours before deadline)
- For cancellations eligible within 24 hours

### Implementation:
- Use `APScheduler` library for background job scheduling
- Or use `Celery` + `Redis` for more advanced queuing (Optional)
- Store email status in database (email_sent flag)
- Retry logic for failed emails (exponential backoff)

---

## 🚀 Implementation Phases

### Phase 1: MVP (Weeks 1-3)
- [x] Project structure setup
- [ ] Database schema creation
- [ ] Authentication (register, login, logout)
- [ ] Movie browsing & search
- [ ] Seat selection & booking flow
- [ ] Stripe payment integration
- [ ] Booking confirmation page
- [ ] My bookings page

### Phase 2: Enhancement (Weeks 4-5)
- [ ] Favorites system
- [ ] Email notifications
- [ ] Background job scheduling
- [ ] Admin dashboard (basic)
- [ ] Analytics
- [ ] Responsive design polish

### Phase 3: Advanced (Weeks 6+)
- [ ] Social login (Google)
- [ ] OTP registration
- [ ] Wallet/Prepaid balance
- [ ] Referral rewards
- [ ] Advanced admin analytics
- [ ] Mobile app (future)

---

## 🔧 Configuration & Environment Variables

### `.env` File Template:
```
# Flask
FLASK_ENV=production
FLASK_SECRET_KEY=your-secret-key-here

# MongoDB
MONGO_URI=mongodb+srv://user:pass@cluster.mongodb.net/cinebook
MONGO_DB_NAME=cinebook

# Stripe
STRIPE_PUBLIC_KEY=pk_live_...
STRIPE_SECRET_KEY=sk_live_...

# Email (Gmail SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_FROM_EMAIL=noreply@cinebook.com

# App Settings
BOOKING_HOLD_TIME=600              # 10 minutes in seconds
ADMIN_EMAIL=admin@cinebook.com
SUPPORT_EMAIL=support@cinebook.com
APP_URL=https://cinebook.com

# Pagination
MOVIES_PER_PAGE=12
BOOKINGS_PER_PAGE=10
```

---

## 🧪 Testing Checklist

### Functional Tests:
- [ ] User can register and login
- [ ] User can browse movies and filter
- [ ] User can select seats and see real-time availability
- [ ] User can complete payment via Stripe (test card: 4242 4242 4242 4242)
- [ ] Booking confirmation email sent
- [ ] Admin can create/edit shows
- [ ] Admin can view analytics
- [ ] User can cancel booking and get refund
- [ ] Reminder email sent 8 hours before show

### Edge Cases:
- [ ] Concurrent seat selection (race condition handling)
- [ ] Double payment prevention
- [ ] Expired payment intents
- [ ] Session timeout
- [ ] Invalid seat selections
- [ ] Show cancellation (notify users)

---

## 📱 Responsive Design Breakpoints

```css
Mobile:  < 640px
Tablet:  640px - 1024px
Desktop: > 1024px
```

### Key Responsive Elements:
- Navigation: Hamburger menu on mobile
- Seat selection: Horizontal scroll on small screens
- Booking table: Cards on mobile, table on desktop
- Admin dashboard: Sidebar collapses on mobile

---

## 🌐 Deployment Strategy

### Frontend (Static Assets)
- Host on **Vercel** or **Netlify**
- Build: No build step (vanilla JS)
- Environment: Use config file for API endpoints

### Backend API
- Host on **Render** or **Railway**
- Environment variables configured in platform dashboard
- Database: **MongoDB Atlas** (cloud)
- Email: Gmail SMTP or SendGrid

### Database
- **MongoDB Atlas** (Cloud MongoDB)
- Backups: Automated daily
- Connection pooling: 100 connections max

### CI/CD (Optional)
- GitHub Actions for automated testing
- Auto-deploy on main branch push

---

## 📚 Additional Considerations

### Security:
- [ ] Rate limiting on API endpoints
- [ ] CSRF protection
- [ ] SQL injection prevention (MongoDB injection)
- [ ] XSS protection
- [ ] CORS configuration

### Performance:
- [ ] Image optimization & CDN
- [ ] Database indexing strategy
- [ ] API response caching
- [ ] Frontend minification
- [ ] Lazy loading for images
- [ ] Skeleton loaders while fetching data

### Accessibility:
- [ ] WCAG 2.1 AA compliance
- [ ] Keyboard navigation
- [ ] Screen reader support
- [ ] Color contrast ratios
- [ ] ARIA labels

---

## 📖 Reference Links

- [Flask Documentation](https://flask.palletsprojects.com/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [Stripe API Reference](https://stripe.com/docs/api)
- [APScheduler Documentation](https://apscheduler.readthedocs.io/)
- [SMTP Email Setup](https://support.google.com/accounts/answer/185833)

---

## 📝 Next Steps

1. **Review & Approve** this architecture
2. **Update requirements.txt** with additional packages
3. **Create database collections** in MongoDB
4. **Refactor app.py** into modular blueprint structure
5. **Build API endpoints** according to spec
6. **Develop frontend pages** following the design system

---

*Last Updated: May 24, 2026*
*Ready to begin implementation? Let's start with Phase 1!*
