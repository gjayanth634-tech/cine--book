import * as THREE from 'https://cdn.skypack.dev/three@0.132.2';
const socket = window.io ? window.io() : null;

// ── STATE ─────────────────────────────────────────────────────
const STATE = {
  movies: [],
  currentCity: 'Bangalore',
  user: null,
  favorites: [],
  booking: {
    movie: null, theater: null, city: null, date: null,
    showtime: null, format: null, seats: [], addons: [], total: 0,
    payMethod: 'upi', step: 1
  },
  heroIndex: 0,
  heroInterval: null,
  bookings: [],
  isAdminView: false,
  accessibility: { darkMode: true, largeText: false }
};

// ── INIT ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Initialize UI components that don't depend on API data immediately
    buildCityGrid();
    buildTheaters();
    setupSearch();
    drawQR();
    setUpiTimer();

    // Start critical API calls in parallel - use allSettled so one failure doesn't block the UI
    await Promise.allSettled([
      loadMovies(),
      checkSession()
    ]);

    startHero();
  } catch (err) {
    console.error("Critical Initialization Error:", err);
  } finally {
    // Hide loader immediately to resolve "infinite loading"
    const loader = document.getElementById('loading-screen');
    if (loader) {
      loader.style.opacity = '0';
      setTimeout(() => { if(loader) loader.style.display = 'none'; }, 400);
    }
  }

  // Socket Listeners for Real-time Seats
  if (socket) {
    socket.on('seat_status_update', (data) => {
      const el = document.querySelector(`[data-seat="${data.seat_id}"]`);
      if (el) {
          el.className = `seat ${data.status === 'locked' ? 'selected' : 'available'}`;
      }
    });
  }
});

// ── API HELPERS ────────────────────────────────────────────────
async function api(path, opts={}) {
  try {
    const r = await fetch(path, { headers: {'Content-Type':'application/json'}, ...opts });
    return r.json();
  } catch(e) { return null; }
}

// ── MOVIES ────────────────────────────────────────────────────
async function loadMovies() {
  const data = await api('/api/movies');
  if (!data) return;
  STATE.movies = data;
  
  // Render critical UI first
  renderMovies(data.filter(m => m.status === 'now_showing'));
  renderComingSoon(data.filter(m => m.status === 'coming_soon'));
  buildHero(data);
  renderDashMovies(data.slice(0,4));

  // Load secondary data in the background without blocking
  loadFavorites();
  loadRecommendations();
}

async function loadRecommendations() {
    const data = await api('/api/recommendations');
    if (data) {
        const g = document.getElementById('recs-grid');
        if (g) g.innerHTML = data.map(m => movieCard(m)).join('');
    }
}

function renderMovies(movies) {
  const g = document.getElementById('movies-grid');
  if (!g) return;
  g.innerHTML = movies.map(m => movieCard(m)).join('');
}

function renderFavorites() {
  const g = document.getElementById('favorites-grid');
  if (!g) return;
  const favMovies = STATE.movies.filter(m => STATE.favorites.includes(m.id));
  if (!favMovies.length) g.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:100px;color:var(--muted)">No favorites yet. Start liking some movies!</div>';
  else g.innerHTML = favMovies.map(m => movieCard(m)).join('');
}

function renderComingSoon(movies) {
  const g = document.getElementById('coming-grid');
  if (!g) return;
  g.innerHTML = movies.map(m => movieCard(m, true)).join('');
}

function renderDashMovies(movies) {
  const g = document.getElementById('dash-movies');
  if (!g) return;
  g.innerHTML = movies.map(m => movieCard(m)).join('');
}

function movieCard(m, soon=false) {
  const isFav = STATE.favorites.includes(m.id);
  return `
  <div class="movie-card" onclick="openBooking('${m.id}')">
    <div class="movie-card-img">
      <img src="${m.image}" alt="${m.title}" loading="lazy">
      <div class="fav-badge ${isFav?'active':''}" onclick="event.stopPropagation();toggleFavorite('${m.id}')"><i class="fa${isFav?'s':'r'} fa-heart"></i></div>
      ${m.tags && m.tags[0] ? `<div class="movie-tag">${m.tags[0]}</div>` : ''}
      <div style="position:absolute; bottom:10px; right:10px; display:flex; gap:5px;">
        ${m.accessibility?.subtitles ? `<span class="meta-chip" style="font-size:8px; opacity:0.8; background:#000" title="Subtitles Available">CC</span>` : ''}
        ${m.accessibility?.audio_desc ? `<span class="meta-chip" style="font-size:8px; opacity:0.8; background:#000" title="Audio Description Available">AD</span>` : ''}
      </div>
    </div>
    <div class="movie-card-body">
      <h3>${m.title}</h3>
      <div class="genre">${m.genre} • ${m.language}</div>
      <div class="movie-rating">
        <div class="rating-badge"><i class="fas fa-star"></i>${m.rating}</div>
        <span style="font-size:11px;color:var(--muted)">${m.votes} votes</span>
      </div>
    </div>
  </div>`;
}

async function loadFavorites() {
  if (!STATE.user) return;
  const data = await api('/api/favorites');
  if (data) {
    STATE.favorites = data;
    renderMovies(STATE.movies);
  }
}

async function toggleFavorite(movieId) {
  if (!STATE.user) { openAuth('login'); return; }
  const data = await api('/api/favorites', {method:'POST', body:JSON.stringify({movie_id: movieId})});
  if (data?.success) {
    STATE.favorites = data.favorites;
    renderMovies(STATE.movies);
    toast(STATE.favorites.includes(movieId) ? 'Added to favorites' : 'Removed from favorites', 'success');
  }
}

function filterMovies(genre, btn) {
  document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  const filtered = genre === 'All' ? STATE.movies : STATE.movies.filter(m =>
    m.genre.toLowerCase().includes(genre.toLowerCase()) ||
    m.language.toLowerCase().includes(genre.toLowerCase())
  );
  renderMovies(filtered.length ? filtered : STATE.movies);
}

function filterByMood(mood, btn) {
    document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
    btn.classList.add('active');
    const filtered = STATE.movies.filter(m => 
        m.moods && m.moods.some(mo => mo.toLowerCase() === mood.toLowerCase())
    );
    renderMovies(filtered.length ? filtered : STATE.movies);
    toast(`Filtering for ${mood} movies`, 'info');
}

async function rentMovieOnline(movieId) {
  if (!STATE.user) { openAuth('login'); return; }
  const m = STATE.movies.find(mo => mo.id === movieId);
  if (confirm(`Rent ${m.title} for ₹${m.ott_price}?`)) {
    const res = await api('/api/ott/rent', { method: 'POST', body: JSON.stringify({ movie_id: movieId }) });
    if (res?.success) {
      toast(res.message, 'success');
      showPage('dashboard');
    }
  }
}

function buildHero(movies) {
  const slides = document.getElementById('hero-slides');
  const content = document.getElementById('hero-content');
  const dots = document.getElementById('hero-dots');
  if (!slides || !dots) return;

  slides.innerHTML = movies.slice(0,4).map((m,i) => `
    <div class="hero-slide ${i===0?'active':''}" data-idx="${i}">
      <img src="${m.banner}" alt="${m.title}">
    </div>`).join('');

  dots.innerHTML = movies.slice(0,4).map((_,i) =>
    `<div class="hero-dot ${i===0?'active':''}" onclick="goHero(${i})"></div>`
  ).join('');

  updateHeroContent(movies[0]);
}

function updateHeroContent(m) {
  const el = document.getElementById('hero-content');
  if (!el) return;
  el.innerHTML = `
    <div class="hero-badge">⭐ ${m.rating}/10 · ${m.votes} votes</div>
    <div class="hero-title">${m.title}</div>
    <div class="hero-meta">
      <span>${m.duration}</span><span>•</span><span>${m.genre}</span><span>•</span>
      <span>${m.language}</span>
    </div>
    <div class="hero-desc">${m.description}</div>
    <button class="btn-book-hero" onclick="openBooking('${m.id}')">
      <i class="fas fa-ticket-alt"></i> Book Tickets
    </button>`;
    if(m.ott_price && el) {
        el.innerHTML += `<button class="btn-book-hero outline" style="margin-left:10px" onclick="rentMovieOnline('${m.id}')">Rent Online</button>`;
    }
}

function startHero() {
  if (!STATE.movies || STATE.movies.length === 0) return;
  STATE.heroInterval = setInterval(() => {
    goHero((STATE.heroIndex + 1) % STATE.movies.slice(0,4).length);
  }, 4500);
}

function goHero(idx) {
  STATE.heroIndex = idx;
  document.querySelectorAll('.hero-slide').forEach((s,i) =>
    s.classList.toggle('active', i === idx));
  document.querySelectorAll('.hero-dot').forEach((d, i) =>
    d.classList.toggle('active', i === idx));
  updateHeroContent(STATE.movies[idx]);
}

// ── SEARCH ────────────────────────────────────────────────────
function setupSearch() {
  const inp = document.getElementById('search-input');
  const dd = document.getElementById('search-dropdown');
  let timeout;
  inp.addEventListener('input', () => {
    clearTimeout(timeout);
    timeout = setTimeout(async () => {
      const q = inp.value.trim();
      if (!q) { dd.classList.remove('open'); return; }
      const data = await api(`/api/search?q=${encodeURIComponent(q)}`);
      if (!data || !data.length) { dd.classList.remove('open'); return; }
      dd.innerHTML = data.slice(0,5).map(m => `
        <div class="search-item" onclick="openBooking('${m.id}')">
          <img src="${m.image}" alt="${m.title}">
          <div class="search-item-info">
            <h4>${m.title}</h4>
            <p>${m.genre} • ${m.language} • ⭐ ${m.rating}</p>
          </div>
        </div>`).join('');
      dd.classList.add('open');
    }, 300);
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.nav-search')) dd.classList.remove('open');
  });
}

// VOICE SEARCH (Web Speech API)
function startVoiceSearch() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) { toast("Voice search not supported in this browser", "error"); return; }
    
    const recognition = new SpeechRecognition();
    recognition.onstart = () => {
        toast("Listening for movie titles...", "info");
        document.getElementById('search-input').classList.add('pulse-border');
    };
    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        document.getElementById('search-input').value = transcript;
        document.getElementById('search-input').classList.remove('pulse-border');
        const e = new Event('input', { bubbles: true });
        document.getElementById('search-input').dispatchEvent(e);
        toast(`Searching for "${transcript}"`, "success");
    };
    recognition.onerror = () => document.getElementById('search-input').classList.remove('pulse-border');
    recognition.start();
}

// AI TRAILER SUMMARIZER
async function summarizeTrailer(movieId) {
    toast("AI is analyzing trailer frames...", "info");
    const res = await api('/api/ai/summarize-trailer', {method:'POST', body:JSON.stringify({movie_id: movieId})});
    if(res) {
        const modal = document.createElement('div');
        modal.className = 'overlay active';
        modal.innerHTML = `
            <div class="modal" style="padding:30px; text-align:center;">
                <h3>AI Trailer Insights</h3>
                <p style="margin:15px 0; color:var(--muted)">${res.summary}</p>
                <div style="display:flex; justify-content:center; gap:10px;">${res.detected_emotions.map(e => `<span class="meta-chip">${e}</span>`).join('')}</div>
                <button class="btn-primary" style="margin-top:20px" onclick="this.parentElement.parentElement.remove()">Close</button>
            </div>`;
        document.body.appendChild(modal);
    }
}

// SOCIAL FEATURES
async function createWatchParty(movieId) {
    const res = await api('/api/social/watch-party', {method:'POST', body:JSON.stringify({movie_id: movieId})});
    if(res?.success) {
        const link = `https://cinebook.com/join/${res.code}`;
        navigator.clipboard.writeText(link);
        toast(`Watch Party Created! Link copied to clipboard: ${res.code}`, 'success');
    }
}

function shareOnWhatsApp() {
    const movie = STATE.booking.movie.title;
    const seats = STATE.booking.seats.join(', ');
    const text = encodeURIComponent(`I just booked seats ${seats} for ${movie} on CineBook! Join me?`);
    window.open(`https://wa.me/?text=${text}`, '_blank');
}

async function submitReview(movieId) {
    const comment = document.getElementById('review-text').value;
    const rating = document.getElementById('review-rating').value;
    const is_spoiler = document.getElementById('review-spoiler').checked;
    const res = await api('/api/reviews', {method:'POST', body:JSON.stringify({movie_id: movieId, rating, comment, is_spoiler})});
    if(res?.success) {
        toast('Review posted! You earned 10 points.', 'success');
        showPage('home');
    }
}

async function loadLeaderboard() {
    const data = await api('/api/social/leaderboard');
    const box = document.getElementById('leaderboard-list');
    if(box && data) {
        box.innerHTML = data.map((u, i) => `<div>#${i+1} ${u.name} — ${u.points} pts</div>`).join('');
    }
}

// ACCESSIBILITY & UX
function toggleTheme() {
    STATE.accessibility.darkMode = !STATE.accessibility.darkMode;
    document.body.classList.toggle('light-mode', !STATE.accessibility.darkMode);
    toast(`Theme switched to ${STATE.accessibility.darkMode?'Dark':'Light'} mode`, 'info');
}

function toggleLargeText() {
    STATE.accessibility.largeText = !STATE.accessibility.largeText;
    document.body.classList.toggle('large-text', STATE.accessibility.largeText);
    toast(`Large text mode ${STATE.accessibility.largeText?'enabled':'disabled'}`, 'info');
}

// CHATBOT
async function sendChatMessage() {
    const inp = document.getElementById('chat-input');
    const box = document.getElementById('chat-box');
    const msg = inp.value.trim();
    if(!msg) return;
    box.innerHTML += `<div style="text-align:right; margin: 4px 0; color: var(--red)">${msg}</div>`;
    inp.value = '';
    const res = await api('/api/chat', {method:'POST', body:JSON.stringify({message: msg})});
    box.innerHTML += `<div style="margin: 4px 0; font-style: italic;">${res.reply}</div>`;
    box.scrollTop = box.scrollHeight;
}

// ── CITY ──────────────────────────────────────────────────────
const ALL_CITIES = [
  'Mumbai','Delhi','Bangalore','Chennai','Hyderabad','Kolkata','Pune','Ahmedabad','Jaipur','Lucknow','Mysore','Mangalore','Hubli','Kochi','Indore','Chandigarh','Patna','Bhubaneswar',
  'Belgaum','Gulbarga','Surat','Nagpur','Visakhapatnam','Bhopal','Coimbatore','Vadodara',
  'Davanagere','Shimoga','Bellary','Tumkur','Ranchi','Guwahati','Vijayawada','Amritsar',
  'Dehradun','Jodhpur'
];

function buildCityGrid(filter='') {
  const g = document.getElementById('city-grid');
  const cities = filter ? ALL_CITIES.filter(c => c.toLowerCase().includes(filter.toLowerCase())) : ALL_CITIES;
  g.innerHTML = cities.map(c => `
    <div class="city-chip ${c===STATE.currentCity?'selected':''}" onclick="selectCity('${c}')">
      ${c}
    </div>`).join('');
}

function selectCity(city) {
  STATE.currentCity = city;
  document.getElementById('selected-city').textContent = city;
  document.getElementById('theater-city-name').textContent = city;
  document.getElementById('book-city').textContent = city;
  buildCityGrid();
  buildTheaters();
  closeCityModal();
  toast(`City changed to ${city}`, 'info');
}

function filterCities(val) { buildCityGrid(val); }
function openCityModal() { document.getElementById('city-overlay').classList.add('active'); }
function closeCityModal() { document.getElementById('city-overlay').classList.remove('active'); }

// ── THEATERS ─────────────────────────────────────────────────
async function buildTheaters() {
  const data = await api(`/api/theaters/${STATE.currentCity}`);
  const grid = document.getElementById('theaters-grid');
  if (!grid || !data) return;
  grid.innerHTML = data.map(t => `
    <div class="theater-card">
      <h4>${t.name}</h4>
      <div class="t-addr">${t.address}</div>
      <div class="t-dist"><i class="fas fa-map-marker-alt"></i> ${t.distance} away</div>
      <div class="theater-facilities">
        ${t.facilities.map(f => `<span class="theater-fac">${f}</span>`).join('')}
      </div>
    </div>`).join('');
}

// ── AUTH ──────────────────────────────────────────────────────
function openAuth(mode) {
  document.getElementById('auth-overlay').classList.add('active');
  document.getElementById('login-modal').style.display = mode==='login' ? 'block' : 'none';
  document.getElementById('register-modal').style.display = mode==='register' ? 'block' : 'none';
}
function closeAuth() { document.getElementById('auth-overlay').classList.remove('active'); }

function togglePwd(id, btn) {
  const inp = document.getElementById(id);
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.innerHTML = `<i class="fas fa-${inp.type==='password'?'eye':'eye-slash'}"></i>`;
}

async function doLogin() {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  if (!email || !password) { toast('Please fill all fields','error'); return; }
  const data = await api('/api/login', {method:'POST', body:JSON.stringify({email,password})});
  if (data?.success) {
    STATE.user = data.user;
    updateNavUser();
    closeAuth();
    toast(`Welcome back, ${data.user.name}!`, 'success');
    loadBookings();
  } else {
    toast(data?.message || 'Login failed', 'error');
  }
}

async function doRegister() {
  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const password = document.getElementById('reg-password').value;
  const confirm = document.getElementById('reg-confirm').value;
  if (!name||!email||!phone||!password) { toast('Please fill all fields','error'); return; }
  if (phone.length !== 10 || isNaN(phone)) {
    toast('Please enter a valid 10-digit mobile number', 'error');
    return;
  }
  if (password !== confirm) { toast('Passwords do not match','error'); return; }
  if (password.length < 6) { toast('Password must be at least 6 characters','error'); return; }
  const data = await api('/api/register', {method:'POST', body:JSON.stringify({name,email,phone,password})});
  if (data?.success) {
    toast('Account created! Please sign in.', 'success');
    openAuth('login');
    document.getElementById('login-email').value = email;
  } else {
    toast(data?.message || 'Registration failed','error');
  }
}

async function socialLogin(provider) {
  toast(`Connecting to ${provider}...`, 'info');
  const data = await api('/api/auth/google', { method: 'POST' });
  if (data?.success) {
    STATE.user = data.user;
    updateNavUser();
    closeAuth();
    toast(`Signed in via ${provider} as ${data.user.name}`, 'success');
    loadBookings();
  }
}

async function logout() {
  await api('/api/logout', {method:'POST'});
  STATE.user = null;
  STATE.bookings = [];
  updateNavUser();
  showPage('home');
  toast('Logged out successfully', 'info');
}

async function checkSession() {
  const data = await api('/api/session');
  if (data?.logged_in) {
    STATE.user = data.user;
    updateNavUser();
    loadBookings();
  }
}

function updateNavUser() {
  const auth = document.getElementById('nav-auth');
  const user = document.getElementById('nav-user');
  const dl = document.getElementById('dashboard-link');
  if (STATE.user && auth && user) {
    auth.style.display = 'none';
    user.style.display = 'flex';
    if (document.getElementById('nav-username')) document.getElementById('nav-username').textContent = STATE.user.name;
    if (STATE.user.is_admin && document.getElementById('admin-nav-link')) document.getElementById('admin-nav-link').style.display = 'inline';
    if (document.getElementById('nav-avatar')) document.getElementById('nav-avatar').textContent = STATE.user.name[0].toUpperCase();
    if (dl) dl.style.display = 'inline';
    if (document.getElementById('dash-name')) document.getElementById('dash-name').textContent = STATE.user.name;
    if (document.getElementById('profile-avatar-big')) document.getElementById('profile-avatar-big').textContent = STATE.user.name[0].toUpperCase();
    if (document.getElementById('profile-name-big')) document.getElementById('profile-name-big').textContent = STATE.user.name;
    if (document.getElementById('profile-email-big')) document.getElementById('profile-email-big').textContent = STATE.user.email;
    if (document.getElementById('profile-phone-big')) document.getElementById('profile-phone-big').textContent = '📱 ' + STATE.user.phone;
    if (document.getElementById('user-referral-code')) document.getElementById('user-referral-code').textContent = STATE.user.ref_code;
    if (document.getElementById('user-wallet-balance')) document.getElementById('user-wallet-balance').textContent = (STATE.user.wallet || 0).toFixed(2);

    const setInpName = document.getElementById('settings-name');
    const setInpPhone = document.getElementById('settings-phone');
    if (setInpName) setInpName.value = STATE.user.name;
    if (setInpPhone) setInpPhone.value = STATE.user.phone;
    
    // Badges in Dashboard
    const bGrid = document.getElementById('badge-grid');
    if(bGrid && STATE.user.badges) 
        bGrid.innerHTML = STATE.user.badges.map(b => `<div class="badge-item"><i class="fas fa-medal"></i> ${b}</div>`).join('');
  } else {
    auth.style.display = 'flex';
    user.style.display = 'none';
    if (dl) dl.style.display = 'none';
    document.getElementById('admin-nav-link').style.display = 'none';
  }
}

// ── BOOKINGS ──────────────────────────────────────────────────
async function loadBookings() {
  const data = await api('/api/bookings');
  if (data) {
    STATE.bookings = data;
    renderBookingHistory();
    updateDashboardStats();
  }
}

function renderBookingHistory() {
  const hist = document.getElementById('booking-history');
  const dashBk = document.getElementById('dashboard-bookings');
  if (!STATE.bookings.length) {
    if (hist) hist.innerHTML = '<div style="text-align:center;padding:40px;color:var(--muted);">No bookings yet. Book your first movie!</div>';
    if (dashBk) dashBk.innerHTML = '<div style="color:var(--muted);font-size:13px;">No recent bookings.</div>';
    return;
  }
  const bk = STATE.bookings.slice(0,5).map(b => {
    const movie = STATE.movies.find(m => m.title === b.movie?.title) || {};
    return `
    <div class="booking-history-item">
      <img src="${movie.image || 'https://via.placeholder.com/60x84'}" alt="${b.movie?.title}">
      <div class="booking-info">
        <h4>${b.movie?.title || 'Movie'}</h4>
        <div class="booking-meta">${b.theater?.name || ''} • ${b.date || ''} ${b.showtime || ''}</div>
        <div class="booking-meta" style="margin-top:4px">Seats: ${(b.seats||[]).join(', ')} • ${b.format}</div>
        <div class="booking-meta" style="font-family:monospace;margin-top:4px;color:var(--red)">${b.ticket_id}</div>
      </div>
      <div style="text-align:right;">
        <div class="booking-status confirmed">Confirmed</div>
        <div style="font-size:14px;font-weight:800;margin-top:8px;color:var(--red)">₹${b.total}</div>
      </div>
    </div>`;
  }).join('');
  if (hist) hist.innerHTML = bk;
  if (dashBk) dashBk.innerHTML = bk;
}

function updateDashboardStats() {
  const total = STATE.bookings.length;
  const spent = STATE.bookings.reduce((s,b) => s+(b.total||0), 0);
  document.getElementById('dash-total-bookings').textContent = total;
  document.getElementById('dash-total-spent').textContent = '₹' + spent;
  document.getElementById('dash-movies-watched').textContent = total;
  document.getElementById('dash-streak').textContent = STATE.user?.streak || 0;
  document.getElementById('profile-bookings-count').textContent = total;
  document.getElementById('profile-spent').textContent = '₹' + spent;
}

// ── BOOKING FLOW ──────────────────────────────────────────────
async function openBooking(movieId) {
  if (!STATE.user) { openAuth('login'); toast('Please sign in to book tickets', 'info'); return; }
  
  const movie = STATE.movies.find(m => m.id === movieId);
  if (!movie) return;
  
  STATE.booking = { movie, theater:null, city:STATE.currentCity, date:null, showtime:null, format:null, seats:[], addons: [], total:0, payMethod:'upi', step:1 };
  
  buildBookingHeader(movie);
  buildDateRow();
  buildTheaterList(movie);
  goBookingStep(1);
  
  document.getElementById('booking-overlay').classList.add('active');
}

function closeBooking() {
  document.getElementById('booking-overlay').classList.remove('active');
}

function buildBookingHeader(m) {
  document.getElementById('booking-header').innerHTML = `
    <img src="${m.image}" alt="${m.title}">
    <div class="booking-header-info">
      <h2>${m.title}</h2>
      <div class="meta">
        <span class="meta-chip">⭐ ${m.rating}</span>
        <span class="meta-chip">${m.duration}</span>
        <span class="meta-chip">${m.language}</span>
        <span class="meta-chip">${m.genre}</span>
      </div>
      <div style="font-size:12px;color:var(--muted);margin-top:8px;max-width:400px">${m.description}</div>
      <div class="cast-list" style="margin-top:12px">
        <div style="font-size:10px;text-transform:uppercase;color:var(--muted)">Cast</div>
        <div style="font-size:12px;font-weight:700">${m.cast.join(', ')}</div>
      </div>
    </div>`;
}

function buildDateRow() {
  const row = document.getElementById('date-row');
  const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const dates = [];
  for (let i=0;i<8;i++) {
    const d = new Date(); d.setDate(d.getDate()+i);
    dates.push(d);
  }
  row.innerHTML = dates.map((d,i) => `
    <div class="date-chip ${i===0?'selected':''}" onclick="selectDate(this,'${d.toISOString().split('T')[0]}')">
      <div class="day">${days[d.getDay()]}</div>
      <div class="date">${d.getDate()}</div>
      <div class="month">${months[d.getMonth()]}</div>
    </div>`).join('');
  
  // Select first date
  const first = new Date();
  STATE.booking.date = first.toISOString().split('T')[0];
}

function selectDate(el, date) {
  document.querySelectorAll('.date-chip').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  STATE.booking.date = date;
}

async function buildTheaterList(movie) {
  const data = await api(`/api/theaters/${STATE.booking.city}`);
  const showtimes = await api('/api/showtimes');
  if (!data) return;
  
  const list = document.getElementById('theater-list');
  list.innerHTML = data.map(t => `
    <div class="theater-item" id="ti-${t.id}" onclick="selectTheater('${t.id}')">
      <h4>${t.name}</h4>
      <div class="addr">${t.address} • <span style="color:var(--red)">${t.distance}</span></div>
      <div class="facilities">${t.facilities.map(f => `<span class="facility-tag">${f}</span>`).join('')}</div>
      <div class="showtime-row">
        ${(showtimes||[]).map(s => `
          <button class="showtime-btn" onclick="event.stopPropagation();selectShowtime('${t.id}','${s}',this)">${s}</button>
        `).join('')}
      </div>
    </div>`).join('');
}

function selectTheater(tid) {
  // handled by showtime selection
}

function selectShowtime(theaterId, time, btn) {
  document.querySelectorAll('.showtime-btn').forEach(b => b.classList.remove('selected'));
  document.querySelectorAll('.theater-item').forEach(t => t.classList.remove('selected'));
  btn.classList.add('selected');
  
  const theaters = document.querySelectorAll('.theater-item');
  const tEl = document.getElementById('ti-'+theaterId);
  if (tEl) tEl.classList.add('selected');
  
  // Get theater name from element
  const name = tEl?.querySelector('h4')?.textContent || 'Theater';
  const addr = tEl?.querySelector('.addr')?.textContent || '';
  STATE.booking.theater = { id: theaterId, name, address: addr };
  STATE.booking.showtime = time;
  
  updateSummary();
}

function init3DPreview() {
    const container = document.getElementById('ar-preview-box');
    if(!container) return;
    container.style.display = 'block';
    container.innerHTML = '';
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, container.clientWidth/container.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(renderer.domElement);

    const geometry = new THREE.BoxGeometry(2, 1, 2);
    const material = new THREE.MeshPhongMaterial({ color: 0xE31937 });
    const chair = new THREE.Mesh(geometry, material);
    scene.add(chair);

    const light = new THREE.DirectionalLight(0xffffff, 1);
    light.position.set(5, 5, 5);
    scene.add(light);

    camera.position.z = 5;
    camera.position.y = 2;
    camera.lookAt(0,0,0);

    function animate() {
        requestAnimationFrame(animate);
        chair.rotation.y += 0.01;
        renderer.render(scene, camera);
    }
    animate();
    toast("3D Seat Preview Activated", "info");
}

function buildFormatStep(movie) {
  const prices = movie.price || {'2D': 180, '3D': 280, '4DX': 420};
  const row = document.getElementById('format-row');
  row.innerHTML = Object.entries(prices).map(([fmt, price]) => `
    <div class="format-chip ${fmt===Object.keys(prices)[0]?'selected':''}" onclick="selectFormat('${fmt}',${price},this)">
      <div class="fmt">${fmt}</div>
      <div class="price">from ₹${price}</div>
    </div>`).join('');
  
  STATE.booking.format = Object.keys(prices)[0];
  STATE.booking.basePrice = Object.values(prices)[0];
  
  // Showtimes in step 2
  const row2 = document.getElementById('showtime-row2');
  const times = ['10:00 AM','1:00 PM','4:00 PM','7:00 PM','10:00 PM'];
  row2.innerHTML = times.map(t => `
    <button class="showtime-btn ${t===STATE.booking.showtime?'selected':''}" onclick="selectShowtime2('${t}',this)">${t}</button>
  `).join('');
}

function selectFormat(fmt, price, el) {
  document.querySelectorAll('.format-chip').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
  STATE.booking.format = fmt;
  STATE.booking.basePrice = price;
  updateSummary();
}

function selectShowtime2(time, btn) {
  document.querySelectorAll('#showtime-row2 .showtime-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  STATE.booking.showtime = time;
}

function buildSeatMap() {
  const map = document.getElementById('seat-map');
  const rows = ['A','B','C','D','E','F','G','H','I','J'];
  const cols = 12;
  const soldSeats = new Set();
  // Random sold seats
  for (let i=0;i<25;i++) {
    soldSeats.add(rows[Math.floor(Math.random()*rows.length)] + (Math.floor(Math.random()*cols)+1));
  }
  
  map.innerHTML = `
    <div class="seat-section">
      <div style="text-align:right; margin-bottom:10px;">
        <button class="nav-btn outline" style="padding:4px 10px; font-size:10px" onclick="autoSelectGroup(2)">Select Pair</button>
      </div>
      <div class="seat-section-label">Premium — ₹${(STATE.booking.basePrice||180)+100}</div>
      ${['A','B'].map(r => `
        <div class="seat-row">
          <span style="font-size:10px;color:var(--muted);width:18px;text-align:center">${r}</span>
          ${Array.from({length:cols},(_, i) => {
            const sn = r+(i+1);
            const sold = soldSeats.has(sn);
            const isWheelchair = (r === 'A' && (i === 0 || i === 11));
            return `<div class="seat premium ${sold?'sold':'available'} ${isWheelchair?'wheelchair':''}" data-seat="${sn}" data-premium="1" onclick="${!sold?`toggleSeat(this)`:''}">
              ${isWheelchair ? '<i class="fas fa-wheelchair"></i>' : (!sold ? sn : '')}
            </div>`;
          }).join('')}
        </div>`).join('')}
    </div>
    <div class="seat-section">
      <div class="seat-section-label">Standard — ₹${STATE.booking.basePrice||180}</div>
      ${rows.slice(2).map(r => `
        <div class="seat-row">
          <span style="font-size:10px;color:var(--muted);width:18px;text-align:center">${r}</span>
          ${Array.from({length:cols},(_,i) => {
            const sn = r+(i+1);
            const sold = soldSeats.has(sn);
            return `<div class="seat available ${sold?'sold':''}" data-seat="${sn}" onclick="${!sold?`toggleSeat(this)`:''}">
              ${!sold ? '' : ''}
            </div>`;
          }).join('')}
        </div>`).join('')}
    </div>
  `;
}

function autoSelectGroup(size) {
    // Simplified adjacent seat auto-selection
    STATE.booking.seats = [];
    document.querySelectorAll('.seat.selected').forEach(s => s.classList.remove('selected'));
    
    const rows = ['C','D','E','F']; // Target middle rows for best view
    for(let r of rows) {
        let found = [];
        for(let i=4; i<10; i++) { // Target center columns
            let sn = r + i;
            let el = document.querySelector(`[data-seat="${sn}"]`);
            if(el && el.classList.contains('available')) {
                found.push(sn);
                if(found.length === size) {
                    found.forEach(s => toggleSeat(document.querySelector(`[data-seat="${s}"]`)));
                    toast(`AI selected ${size} adjacent seats for you!`, 'success');
                    return;
                }
            } else { found = []; }
        }
    }
    toast('Could not find adjacent seats in optimal rows.', 'error');
}

function toggleSeat(el) {
  const seat = el.dataset.seat;
  const isPremium = el.dataset.premium === '1';
  
  if (el.classList.contains('selected')) {
    el.classList.remove('selected');
    el.classList.add(isPremium ? 'premium available' : 'available');
    STATE.booking.seats = STATE.booking.seats.filter(s => s !== seat);
  } else {
    if (STATE.booking.seats.length >= 8) { toast('Max 8 seats per booking','error'); return; }
    el.classList.remove('available');
    el.classList.add('selected');
    STATE.booking.seats.push(seat);
    lockSeatRealtime(seat);
  }
  updateSummary();
}

function updateSummary() {
  const cnt = STATE.booking.seats.length;
  const base = STATE.booking.basePrice || 180;
  
  // Calculate total with premium seats
  let total = 0;
  STATE.booking.seats.forEach(s => {
    const el = document.querySelector(`[data-seat="${s}"]`);
    const premium = el?.dataset.premium === '1';
    total += premium ? base + 100 : base;
  });
  
  // Add Addons (Food/Parking)
  STATE.booking.addons.forEach(a => total += a.price);
  
  const convenience = cnt * 30;
  if(cnt > 0) total += convenience;
  STATE.booking.total = total;
  
  document.getElementById('summary-seats').textContent = cnt ? `${cnt} Seat${cnt>1?'s':''} • ₹${base}/seat` : '0 Seats selected';
  document.getElementById('summary-theater').textContent = STATE.booking.theater
    ? `${STATE.booking.theater.name} • ${STATE.booking.showtime||''}` : 'Choose theater & showtime';
  document.getElementById('summary-price').textContent = `₹${total}`;
  
  // Update payment amounts
  ['upi','card','wallet_pay'].forEach(id => {
    const el = document.getElementById(`pay-amount-${id}`);
    if (el) el.textContent = total;
  });
}

function goBookingStep(n) {
  STATE.booking.step = n;
  [1,2,3,4,5].forEach(i => {
    document.getElementById(`book-step${i}`).style.display = i===n ? 'block' : 'none';
    const sEl = document.getElementById(`step-${i}`);
    sEl.classList.toggle('active', i===n);
    sEl.classList.toggle('done', i<n);
    if (i<n) sEl.querySelector('.step-num').innerHTML = '✓';
    else sEl.querySelector('.step-num').textContent = i;
  });
  
  if (n===2 && STATE.booking.movie) buildFormatStep(STATE.booking.movie);
  if (n===3) buildSeatMap();
  if (n===4) buildAddonStep();
  
  const nextBtn = document.getElementById('book-next-btn');
  nextBtn.textContent = n===5 ? '✓ Confirm' : 'Next →';
}

function bookingNext() {
  const { step, theater, showtime, format, seats } = STATE.booking;
  if (step===1) {
    if (!theater || !showtime) { toast('Please select a theater and showtime','error'); return; }
    goBookingStep(2);
  } else if (step===2) {
    if (!format) { toast('Please select a format','error'); return; }
    goBookingStep(3);
  } else if (step===3) {
    if (!seats.length) { toast('Please select at least 1 seat','error'); return; }
    goBookingStep(4);
  } else if (step===4) {
    goBookingStep(5);
  } else if (step===5) {
    processPayment();
  }
}

// ── PAYMENT ───────────────────────────────────────────────────
function selectPayMethod(method) {
  STATE.booking.payMethod = method;
  ['upi','card','wallet'].forEach(m => {
    document.getElementById(`pm-${m}`).classList.toggle('selected', m===method);
  });
  document.getElementById('upi-section').style.display = method==='upi' ? 'block' : 'none';
  document.getElementById('upi-section').classList.toggle('show', method==='upi');
  document.getElementById('card-section').style.display = method==='card' ? 'block' : 'none';
  document.getElementById('card-section').classList.toggle('show', method==='card');
  document.getElementById('wallet-section').style.display = method==='wallet' ? 'block' : 'none';
}

async function processPayment() {
  const { movie, theater, city, date, showtime, format, seats, addons, total, payMethod } = STATE.booking;
  if (!seats.length) { toast('No seats selected','error'); return; }
  
  // Validate UPI
  if (payMethod==='upi') {
    const upiId = document.getElementById('upi-id-input').value;
    // Can use QR or UPI ID
  }
  
  // Validate card
  if (payMethod==='card') {
    const num = document.getElementById('card-number').value.replace(/\s/g,'');
    if (num.length < 16) { toast('Please enter a valid card number','error'); return; }
    if (!document.getElementById('card-cvv').value) { toast('Please enter CVV','error'); return; }
  }
  
  const btn = document.getElementById('book-next-btn');
  btn.disabled = true;
  btn.textContent = 'Processing…';
  
  // Simulate payment processing
  await new Promise(r => setTimeout(r, 1800));
  
  const data = await api('/api/book', {
    method: 'POST',
    body: JSON.stringify({ movie, theater, city, date, showtime, format, seats, addons, total, payment_method: payMethod === 'wallet_pay' ? 'wallet' : payMethod })
  });
  
  btn.disabled = false;
  btn.textContent = '✓ Confirm';
  
  if (data?.success) {
    closeBooking();
    showTicket(data.booking);
    loadBookings();
    toast('Booking confirmed! 🎉', 'success');
  } else {
    toast('Booking failed. Try again.','error');
  }
}

// ── TICKET ────────────────────────────────────────────────────
function showTicket(booking) {
  const barcode = Array.from({length:40}, () =>
    `<div class="barcode-line" style="width:${Math.random()<.3?3:Math.random()<.5?2:1}px;height:${40+Math.random()*20}px"></div>`
  ).join('');
  
  document.getElementById('ticket-content').innerHTML = `
    <div class="ticket-header">
      <div class="brand">🎬 CineBook</div>
      <h3>${booking.movie?.title || 'Movie'}</h3>
    </div>
    <div class="ticket-dashed"></div>
    <div class="ticket-body">
      <div class="ticket-row"><span class="label">Theater</span><span class="val">${booking.theater?.name || ''}</span></div>
      <div class="ticket-row"><span class="label">Date & Time</span><span class="val">${booking.date} · ${booking.showtime}</span></div>
      <div class="ticket-row"><span class="label">Seats</span><span class="val">${(booking.seats||[]).join(', ')}</span></div>
      <div class="ticket-row"><span class="label">Format</span><span class="val">${booking.format}</span></div>
      <div class="ticket-row"><span class="label">Total Paid</span><span class="val" style="color:var(--red)">₹${booking.total}</span></div>
      <div class="ticket-barcode">
        <div class="barcode-lines">${barcode}</div>
        <div class="ticket-id">${booking.ticket_id}</div>
      </div>
    </div>
    <div class="ticket-footer"><i class="fas fa-mobile-alt"></i> Ticket sent to your mobile: ${booking.user_phone}</div>
  `;
  document.getElementById('ticket-overlay').classList.add('active');
  addVoiceControlsToTicket();
  speakBookingDetails();
}

function closeTicket() { document.getElementById('ticket-overlay').classList.remove('active'); }

function downloadTicket() {
  toast('Ticket downloaded to your device!', 'success');
}

// ── QR CODE (canvas draw) ─────────────────────────────────────
function drawQR() {
  const canvas = document.getElementById('qr-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const size = 148;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0,0,size,size);
  
  const cells = 20;
  const cellSize = size/cells;
  ctx.fillStyle = '#000';
  
  // Draw fake QR pattern
  for (let r=0;r<cells;r++) {
    for (let c=0;c<cells;c++) {
      const skip = (r<7&&c<7) || (r<7&&c>cells-8) || (r>cells-8&&c<7);
      if (!skip && Math.random()>0.5) {
        ctx.fillRect(c*cellSize, r*cellSize, cellSize-1, cellSize-1);
      }
    }
  }
  // Corner squares
  [[0,0],[0,cells-7],[cells-7,0]].forEach(([r,c]) => {
    ctx.fillStyle = '#000';
    ctx.fillRect(c*cellSize,r*cellSize,7*cellSize,7*cellSize);
    ctx.fillStyle = '#fff';
    ctx.fillRect(c*cellSize+cellSize,r*cellSize+cellSize,5*cellSize,5*cellSize);
    ctx.fillStyle = '#000';
    ctx.fillRect(c*cellSize+2*cellSize,r*cellSize+2*cellSize,3*cellSize,3*cellSize);
  });
}

// UPI Timer
function setUpiTimer() {
  let secs = 600;
  const el = document.getElementById('upi-timer');
  if (!el) return;
  const t = setInterval(() => {
    secs--;
    if (secs<=0) { clearInterval(t); el.textContent='Expired'; return; }
    el.textContent = `${Math.floor(secs/60).toString().padStart(2,'0')}:${(secs%60).toString().padStart(2,'0')}`;
  }, 1000);
}

// Card formatting
function formatCardNum(inp) {
  let v = inp.value.replace(/\D/g,'').slice(0,16);
  inp.value = v.replace(/(.{4})/g,'$1 ').trim();
  document.getElementById('card-num-display').textContent = (inp.value+'•••• •••• •••• ••••').slice(0,19);
}
function formatExp(inp) {
  let v = inp.value.replace(/\D/g,'');
  if (v.length>=2) v = v.slice(0,2)+'/'+v.slice(2,4);
  inp.value = v;
  document.getElementById('card-exp-display').textContent = inp.value || 'MM/YY';
}

// ── ADMIN LOGIC ──────────────────────────────────────────────
async function adminAddMovie() {
  const movieData = {
    title: document.getElementById('adm-title').value,
    genre: document.getElementById('adm-genre').value,
    language: document.getElementById('adm-lang').value,
    duration: document.getElementById('adm-dur').value,
    rating: document.getElementById('adm-rating').value,
    description: document.getElementById('adm-desc').value,
    cast: document.getElementById('adm-cast').value.split(',').map(s => s.trim())
  };
  
  if (!movieData.title || !movieData.genre) { toast('Title and Genre are required', 'error'); return; }

  const res = await api('/api/admin/movies', { method: 'POST', body: JSON.stringify(movieData) });
  if (res?.success) {
    toast(`Movie "${movieData.title}" added and users notified!`, 'success');
    await loadMovies();
    // Clear form
    document.querySelectorAll('#admin-page-wrap input, #admin-page-wrap textarea').forEach(i => i.value = '');
  } else {
    toast(res?.message || 'Failed to add movie', 'error');
  }
}

// ── PROFILE ACCOUNT MANAGEMENT ──────────────────────────────
function switchProfileTab(tab, el) {
  document.querySelectorAll('.ptab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  
  document.querySelectorAll('.profile-tab-content').forEach(c => c.style.display = 'none');
  document.getElementById(`profile-${tab}-tab`).style.display = 'block';
}

async function saveProfileSettings() {
  const name = document.getElementById('settings-name').value.trim();
  const phone = document.getElementById('settings-phone').value.trim();
  const password = document.getElementById('settings-password').value.trim();
  
  if (!name || !phone) { toast('Name and phone are required', 'error'); return; }
  
  const res = await api('/api/profile/update', { method: 'POST', body: JSON.stringify({ name, phone, password }) });
  if (res?.success) {
    STATE.user = res.user;
    updateNavUser();
    toast(res.message, 'success');
  } else {
    toast(res?.message || 'Update failed', 'error');
  }
}

// ── PAGE NAVIGATION ───────────────────────────────────────────
function showPage(page) {
  STATE.isAdminView = (page === 'admin');
  document.getElementById('navbar').style.display = STATE.isAdminView ? 'none' : 'flex';
  document.querySelector('footer').style.display = STATE.isAdminView ? 'none' : 'block';

  ['home-page','theaters-page','profile-page-wrap','dashboard-page-wrap','admin-page-wrap','favorites-page-wrap'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('active');
  });
  const map = {
    home:'home-page', theaters:'theaters-page', profile:'profile-page-wrap', 
    dashboard:'dashboard-page-wrap', admin:'admin-page-wrap', favorites:'favorites-page-wrap'
  };
  const el = document.getElementById(map[page]);
  if (el) {
    el.classList.add('active');
    el.style.opacity = '0';
    el.style.transform = 'translateY(10px)';
    setTimeout(() => {
      el.style.transition = 'all 0.4s ease';
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    }, 50);
  }
  if (page === 'favorites') renderFavorites();
  
  if (page==='theaters') buildTheaters();
  if (page==='admin') {
      const rev = await api('/api/admin/analytics/revenue');
      if(rev) {
          document.getElementById('revenue-summary').innerHTML = Object.entries(rev.by_movie)
            .map(([k,v]) => `<div>${k}: ₹${v}</div>`).join('');
      }
  }
  if (page==='profile' && !STATE.user) { openAuth('login'); return; }
  if (page==='dashboard' && !STATE.user) { openAuth('login'); return; }
  
  window.scrollTo({top:0,behavior:'smooth'});
}

// ── TOAST ─────────────────────────────────────────────────────
function toast(msg, type='info') {
  const icons = {success:'fa-check-circle', error:'fa-exclamation-circle', info:'fa-info-circle'};
  const colors = {success:'#22c55e', error:'#E31937', info:'#5ac8fa'};
  const div = document.createElement('div');
  div.className = `toast-msg ${type}`;
  div.innerHTML = `<i class="fas ${icons[type]}" style="color:${colors[type]}"></i>${msg}`;
  document.getElementById('toast').appendChild(div);
  setTimeout(() => { div.style.opacity='0'; div.style.transform='translateX(100px)'; div.style.transition='all .3s'; setTimeout(()=>div.remove(), 300); }, 3000);
}

// ── EXPOSE TO GLOBAL SCOPE ─────────────────────────────────────
// Necessary because type="module" isolates functions
window.STATE = STATE;
window.showPage = showPage;
window.openBooking = openBooking;
window.filterMovies = filterMovies;
window.filterByMood = filterByMood;
window.openAuth = openAuth;
window.logout = logout;
window.closeAuth = closeAuth;
window.togglePwd = togglePwd;
window.doLogin = doLogin;
window.doRegister = doRegister;
window.socialLogin = socialLogin;
window.openCityModal = openCityModal;
window.closeCityModal = closeCityModal;
window.filterCities = filterCities;
window.selectCity = selectCity;
window.closeBooking = closeBooking;
window.selectDate = selectDate;
window.selectShowtime = selectShowtime;
window.selectFormat = selectFormat;
window.selectShowtime2 = selectShowtime2;
window.autoSelectGroup = autoSelectGroup;
window.bookingNext = bookingNext;
window.selectPayMethod = selectPayMethod;
window.processPayment = processPayment;
window.closeTicket = closeTicket;
window.saveProfileSettings = saveProfileSettings;
window.switchProfileTab = switchProfileTab;
window.adminAddMovie = adminAddMovie;
window.toggleTheme = toggleTheme;
window.toggleLargeText = toggleLargeText;
window.sendChatMessage = sendChatMessage;
window.toggleFavorite = toggleFavorite;
window.toggleSeat = toggleSeat;
window.init3DPreview = init3DPreview;
window.createWatchParty = createWatchParty;
window.shareOnWhatsApp = shareOnWhatsApp;
window.submitReview = submitReview;
window.rentMovieOnline = rentMovieOnline;
window.goHero = goHero;
window.startVoiceSearch = startVoiceSearch;
