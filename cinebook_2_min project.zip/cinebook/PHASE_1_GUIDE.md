# Phase 1: MVP Implementation Guide
## Movie Ticket Booking System - Core Booking Flow

---

## 📦 Updated Requirements & Dependencies

Add these packages to your project:

```
flask==3.0.0
flask-pymongo==2.3.0
flask-bcrypt==1.0.1
pymongo==4.6.1
python-dotenv==1.0.0
stripe==8.4.0                    # Stripe payment processing
flask-cors==4.0.0                # Cross-origin requests
email-validator==2.1.0           # Email validation
APScheduler==3.10.4              # Background job scheduling
pytz==2024.1                      # Timezone support
```

---

## 🗂️ Step 1: Refactor Project Structure

Convert monolithic `app.py` into a modular Flask application:

### New structure:
```
app/
├── __init__.py                  # Flask app factory
├── config.py                    # Configuration
├── models.py                    # Database models
├── utils.py                     # Helper functions
├── auth.py                      # Auth routes (Blueprint)
├── movies.py                    # Movie routes (Blueprint)
├── bookings.py                  # Booking routes (Blueprint)
├── payments.py                  # Payment routes (Blueprint)
├── admin.py                     # Admin routes (Blueprint)
├── emails.py                    # Email services
├── background_jobs.py           # Scheduled tasks
└── decorators.py                # Custom decorators

static/                          # (Already exists)
templates/                       # (Already exists)
main.py                          # Entry point
```

---

## 🔑 Key Implementation Steps

### Step 1.1: Create Config Module (`app/config.py`)

```python
import os
from datetime import timedelta

class Config:
    """Base configuration"""
    MONGO_URI = os.getenv('MONGO_URI', 'mongodb://localhost:27017/cinebook')
    SECRET_KEY = os.getenv('SECRET_KEY', 'cinebook_secret_2024')
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    
    # Stripe
    STRIPE_PUBLIC_KEY = os.getenv('STRIPE_PUBLIC_KEY')
    STRIPE_SECRET_KEY = os.getenv('STRIPE_SECRET_KEY')
    
    # Email
    SMTP_HOST = os.getenv('SMTP_HOST', 'smtp.gmail.com')
    SMTP_PORT = int(os.getenv('SMTP_PORT', 587))
    SMTP_USER = os.getenv('SMTP_USER')
    SMTP_PASSWORD = os.getenv('SMTP_PASSWORD')
    SMTP_FROM = os.getenv('SMTP_FROM', 'noreply@cinebook.com')
    
    # App Settings
    BOOKING_HOLD_TIME = 600  # 10 minutes
    MAX_SEATS_PER_BOOKING = 10
    CANCELLATION_CUTOFF_HOURS = 6

class DevelopmentConfig(Config):
    DEBUG = True
    SESSION_COOKIE_SECURE = False

class ProductionConfig(Config):
    DEBUG = False

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
```

---

### Step 1.2: Database Models (`app/models.py`)

```python
from pymongo import MongoClient
from datetime import datetime
import os

# MongoDB Connection
client = MongoClient(os.getenv('MONGO_URI', 'mongodb://localhost:27017/'))
db = client['cinebook']

# Collections (Auto-created by MongoDB on first insert)
COLLECTIONS = {
    'users': db.users,
    'movies': db.movies,
    'theaters': db.theaters,
    'screens': db.screens,
    'shows': db.shows,
    'seats': db.seats,
    'bookings': db.bookings,
    'transactions': db.transactions,
}

def init_collections():
    """Create required indexes"""
    # Users indexes
    COLLECTIONS['users'].create_index('email', unique=True)
    
    # Shows indexes
    COLLECTIONS['shows'].create_index([('movie_id', 1), ('show_date', 1)])
    COLLECTIONS['shows'].create_index('status')
    
    # Bookings indexes
    COLLECTIONS['bookings'].create_index([('user_id', 1), ('booking_date', -1)])
    COLLECTIONS['bookings'].create_index('payment_status')
    
    # Seats indexes
    COLLECTIONS['seats'].create_index([('show_id', 1), ('seat_number', 1)])
    
    print("✅ Indexes created")

class Database:
    """Database helper class"""
    
    @staticmethod
    def get_collection(name):
        return COLLECTIONS.get(name)
    
    @staticmethod
    def insert_one(collection_name, data):
        if '_id' not in data:
            data['created_at'] = datetime.utcnow()
        return COLLECTIONS[collection_name].insert_one(data).inserted_id
    
    @staticmethod
    def find_one(collection_name, query):
        return COLLECTIONS[collection_name].find_one(query)
    
    @staticmethod
    def find_many(collection_name, query, limit=0, skip=0):
        return list(COLLECTIONS[collection_name].find(query).limit(limit).skip(skip))
    
    @staticmethod
    def update_one(collection_name, filter_query, update_data):
        update_data['updated_at'] = datetime.utcnow()
        return COLLECTIONS[collection_name].update_one(
            filter_query,
            {'$set': update_data}
        )
    
    @staticmethod
    def delete_one(collection_name, query):
        return COLLECTIONS[collection_name].delete_one(query)
```

---

### Step 1.3: Flask App Factory (`app/__init__.py`)

```python
from flask import Flask
from flask_bcrypt import Bcrypt
from flask_cors import CORS
from .config import config
from .models import init_collections, COLLECTIONS
import os

bcrypt = Bcrypt()

def create_app(config_name='development'):
    app = Flask(__name__, 
                template_folder='../templates',
                static_folder='../static')
    
    # Configuration
    config_obj = config.get(config_name, config['default'])
    app.config.from_object(config_obj)
    
    # Initialize extensions
    bcrypt.init_app(app)
    CORS(app)
    
    # Initialize database collections
    init_collections()
    
    # Register blueprints
    from .auth import auth_bp
    from .movies import movies_bp
    from .bookings import bookings_bp
    from .payments import payments_bp
    from .admin import admin_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(movies_bp, url_prefix='/api/movies')
    app.register_blueprint(bookings_bp, url_prefix='/api/bookings')
    app.register_blueprint(payments_bp, url_prefix='/api/payments')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(e):
        return {'error': 'Not found'}, 404
    
    @app.errorhandler(500)
    def server_error(e):
        return {'error': 'Server error'}, 500
    
    # Health check
    @app.route('/health')
    def health():
        return {'status': 'ok'}
    
    return app
```

---

### Step 1.4: Decorators (`app/decorators.py`)

```python
from functools import wraps
from flask import session, jsonify, request
from .models import Database
from bson.objectid import ObjectId

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Unauthorized'}), 401
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Unauthorized'}), 401
        
        user = Database.find_one('users', {'_id': ObjectId(session['user_id'])})
        if not user or not user.get('is_admin'):
            return jsonify({'error': 'Admin access required'}), 403
        
        return f(*args, **kwargs)
    return decorated_function

def json_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not request.is_json:
            return jsonify({'error': 'JSON required'}), 400
        return f(*args, **kwargs)
    return decorated_function
```

---

### Step 1.5: Authentication Routes (`app/auth.py`)

```python
from flask import Blueprint, request, session, jsonify
from bson.objectid import ObjectId
from . import bcrypt
from .models import Database
from .decorators import login_required

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    
    # Validation
    if not all(k in data for k in ['name', 'email', 'phone', 'password']):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if user exists
    if Database.find_one('users', {'email': data['email']}):
        return jsonify({'error': 'Email already registered'}), 409
    
    # Create user
    user_data = {
        'name': data['name'],
        'email': data['email'],
        'phone': data['phone'],
        'password': bcrypt.generate_password_hash(data['password']).decode('utf-8'),
        'is_admin': False,
        'favorites': [],
        'total_bookings': 0,
        'total_spent': 0.0,
    }
    
    user_id = Database.insert_one('users', user_data)
    
    return jsonify({
        'message': 'User registered successfully',
        'user_id': str(user_id)
    }), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    
    if not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Email and password required'}), 400
    
    user = Database.find_one('users', {'email': data['email']})
    
    if not user or not bcrypt.check_password_hash(user['password'], data['password']):
        return jsonify({'error': 'Invalid credentials'}), 401
    
    session['user_id'] = str(user['_id'])
    session['user_email'] = user['email']
    session['is_admin'] = user.get('is_admin', False)
    
    return jsonify({
        'message': 'Login successful',
        'user': {
            'id': str(user['_id']),
            'name': user['name'],
            'email': user['email'],
            'is_admin': user.get('is_admin', False)
        }
    }), 200

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'}), 200

@auth_bp.route('/profile', methods=['GET'])
@login_required
def get_profile():
    user = Database.find_one('users', {'_id': ObjectId(session['user_id'])})
    return jsonify({
        'id': str(user['_id']),
        'name': user['name'],
        'email': user['email'],
        'phone': user['phone'],
        'total_bookings': user.get('total_bookings', 0),
        'total_spent': user.get('total_spent', 0),
    }), 200

@auth_bp.route('/check-session', methods=['GET'])
def check_session():
    if 'user_id' in session:
        return jsonify({'authenticated': True}), 200
    return jsonify({'authenticated': False}), 200
```

---

### Step 1.6: Movies Routes (`app/movies.py`)

```python
from flask import Blueprint, request, jsonify, session
from bson.objectid import ObjectId
from .models import Database
from .decorators import login_required

movies_bp = Blueprint('movies', __name__)

@movies_bp.route('/', methods=['GET'])
def get_movies():
    # Pagination
    page = int(request.args.get('page', 1))
    per_page = 12
    skip = (page - 1) * per_page
    
    # Filters
    filters = {}
    if request.args.get('genre'):
        filters['genre'] = request.args.get('genre')
    if request.args.get('language'):
        filters['language'] = request.args.get('language')
    
    movies = Database.find_many('movies', filters, limit=per_page, skip=skip)
    
    # Convert ObjectId to string
    for movie in movies:
        movie['_id'] = str(movie['_id'])
    
    return jsonify({'movies': movies, 'page': page}), 200

@movies_bp.route('/<movie_id>', methods=['GET'])
def get_movie(movie_id):
    try:
        movie = Database.find_one('movies', {'_id': ObjectId(movie_id)})
        if not movie:
            return jsonify({'error': 'Movie not found'}), 404
        
        movie['_id'] = str(movie['_id'])
        return jsonify(movie), 200
    except:
        return jsonify({'error': 'Invalid movie ID'}), 400

@movies_bp.route('/<movie_id>/shows', methods=['GET'])
def get_shows_for_movie(movie_id):
    try:
        # Get shows for this movie, grouped by date
        show_date = request.args.get('date')  # Format: YYYY-MM-DD
        
        query = {'movie_id': ObjectId(movie_id), 'status': 'active'}
        if show_date:
            query['show_date'] = {'$regex': f'^{show_date}'}
        
        shows = Database.find_many('shows', query)
        
        for show in shows:
            show['_id'] = str(show['_id'])
            show['movie_id'] = str(show['movie_id'])
            show['screen_id'] = str(show['screen_id'])
        
        return jsonify({'shows': shows}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@movies_bp.route('/<movie_id>/favorite', methods=['POST'])
@login_required
def toggle_favorite(movie_id):
    try:
        user = Database.find_one('users', {'_id': ObjectId(session['user_id'])})
        favorites = user.get('favorites', [])
        
        if movie_id in favorites:
            favorites.remove(movie_id)
            action = 'removed'
        else:
            favorites.append(movie_id)
            action = 'added'
        
        Database.update_one('users', 
            {'_id': ObjectId(session['user_id'])},
            {'favorites': favorites}
        )
        
        return jsonify({
            'message': f'Movie {action} to favorites',
            'favorites': favorites
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@movies_bp.route('/favorites', methods=['GET'])
@login_required
def get_favorites():
    user = Database.find_one('users', {'_id': ObjectId(session['user_id'])})
    favorites = user.get('favorites', [])
    
    movies = []
    for movie_id in favorites:
        movie = Database.find_one('movies', {'_id': ObjectId(movie_id)})
        if movie:
            movie['_id'] = str(movie['_id'])
            movies.append(movie)
    
    return jsonify({'favorites': movies}), 200
```

---

### Step 1.7: Bookings Routes (`app/bookings.py`)

```python
from flask import Blueprint, request, jsonify, session
from bson.objectid import ObjectId
from datetime import datetime, timedelta
from .models import Database
from .decorators import login_required
import uuid

bookings_bp = Blueprint('bookings', __name__)

@bookings_bp.route('/<show_id>/seats', methods=['GET'])
def get_seats(show_id):
    """Get seat layout for a show"""
    try:
        show = Database.find_one('shows', {'_id': ObjectId(show_id)})
        if not show:
            return jsonify({'error': 'Show not found'}), 404
        
        # Get seats for this show
        seats = Database.find_many('seats', {'show_id': ObjectId(show_id)})
        
        for seat in seats:
            seat['_id'] = str(seat['_id'])
            seat['show_id'] = str(seat['show_id'])
        
        return jsonify({
            'show': {
                '_id': str(show['_id']),
                'movie_id': str(show['movie_id']),
                'show_date': show['show_date'],
                'show_time': show['show_time'],
                'format': show['format'],
                'ticket_price': show['ticket_price'],
            },
            'seats': seats
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bookings_bp.route('/reserve', methods=['POST'])
@login_required
def reserve_seats():
    """Temporary seat reservation (hold for 10 minutes)"""
    data = request.get_json()
    show_id = data.get('show_id')
    seat_ids = data.get('seat_ids', [])
    
    if not show_id or not seat_ids:
        return jsonify({'error': 'Show and seats required'}), 400
    
    try:
        # Create temporary booking record
        booking = {
            'user_id': ObjectId(session['user_id']),
            'show_id': ObjectId(show_id),
            'seat_ids': [ObjectId(s) for s in seat_ids],
            'status': 'reserved',
            'reserved_at': datetime.utcnow(),
            'expires_at': datetime.utcnow() + timedelta(minutes=10),
            'payment_status': 'pending'
        }
        
        booking_id = Database.insert_one('bookings', booking)
        
        # Update seat status
        for seat_id in seat_ids:
            Database.update_one('seats',
                {'_id': ObjectId(seat_id)},
                {'status': 'reserved', 'reserved_by': ObjectId(session['user_id'])}
            )
        
        return jsonify({
            'reservation_id': str(booking_id),
            'expires_at': booking['expires_at'].isoformat()
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bookings_bp.route('/cancel-reserve/<reservation_id>', methods=['DELETE'])
@login_required
def cancel_reservation(reservation_id):
    """Cancel seat reservation"""
    try:
        booking = Database.find_one('bookings', {'_id': ObjectId(reservation_id)})
        if not booking:
            return jsonify({'error': 'Reservation not found'}), 404
        
        # Release seats
        for seat_id in booking['seat_ids']:
            Database.update_one('seats',
                {'_id': ObjectId(seat_id)},
                {'status': 'available', 'reserved_by': None}
            )
        
        # Delete booking
        Database.delete_one('bookings', {'_id': ObjectId(reservation_id)})
        
        return jsonify({'message': 'Reservation cancelled'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bookings_bp.route('/my-bookings', methods=['GET'])
@login_required
def get_my_bookings():
    """Get all bookings for current user"""
    status = request.args.get('status')  # Filter: upcoming, past, cancelled
    
    query = {'user_id': ObjectId(session['user_id']), 'payment_status': 'completed'}
    
    bookings = Database.find_many('bookings', query)
    
    for booking in bookings:
        booking['_id'] = str(booking['_id'])
        booking['user_id'] = str(booking['user_id'])
        booking['show_id'] = str(booking['show_id'])
        booking['seat_ids'] = [str(s) for s in booking['seat_ids']]
    
    return jsonify({'bookings': bookings}), 200

@bookings_bp.route('/<booking_id>', methods=['GET'])
@login_required
def get_booking(booking_id):
    """Get specific booking details"""
    try:
        booking = Database.find_one('bookings', {'_id': ObjectId(booking_id)})
        if not booking:
            return jsonify({'error': 'Booking not found'}), 404
        
        if str(booking['user_id']) != session['user_id']:
            return jsonify({'error': 'Unauthorized'}), 403
        
        booking['_id'] = str(booking['_id'])
        booking['user_id'] = str(booking['user_id'])
        booking['show_id'] = str(booking['show_id'])
        booking['seat_ids'] = [str(s) for s in booking['seat_ids']]
        
        return jsonify(booking), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@bookings_bp.route('/<booking_id>/cancel', methods=['POST'])
@login_required
def cancel_booking(booking_id):
    """Cancel a completed booking and process refund"""
    try:
        booking = Database.find_one('bookings', {'_id': ObjectId(booking_id)})
        if not booking:
            return jsonify({'error': 'Booking not found'}), 404
        
        if str(booking['user_id']) != session['user_id']:
            return jsonify({'error': 'Unauthorized'}), 403
        
        # Check if cancellation is allowed (6 hours before show)
        show = Database.find_one('shows', {'_id': ObjectId(booking['show_id'])})
        show_datetime = datetime.fromisoformat(show['show_date'] + 'T' + show['show_time'])
        
        hours_until_show = (show_datetime - datetime.utcnow()).total_seconds() / 3600
        
        if hours_until_show < 6:
            return jsonify({'error': 'Cannot cancel within 6 hours of showtime'}), 400
        
        # Release seats
        for seat_id in booking['seat_ids']:
            Database.update_one('seats',
                {'_id': ObjectId(seat_id)},
                {'status': 'available', 'booked_by': None}
            )
        
        # Update booking status
        cancellation_fee = booking['total_amount'] * 0.1  # 10% cancellation fee
        refund_amount = booking['total_amount'] - cancellation_fee
        
        Database.update_one('bookings',
            {'_id': ObjectId(booking_id)},
            {
                'booking_status': 'cancelled',
                'cancelled_at': datetime.utcnow(),
                'refund_amount': refund_amount,
                'cancellation_fee': cancellation_fee
            }
        )
        
        return jsonify({
            'message': 'Booking cancelled successfully',
            'refund_amount': refund_amount,
            'cancellation_fee': cancellation_fee
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
```

---

### Step 1.8: Payment Routes (`app/payments.py`)

```python
from flask import Blueprint, request, jsonify, session
from bson.objectid import ObjectId
from datetime import datetime
from .models import Database
from .decorators import login_required
import stripe
import os

payments_bp = Blueprint('payments', __name__)

stripe.api_key = os.getenv('STRIPE_SECRET_KEY')

@payments_bp.route('/create-intent', methods=['POST'])
@login_required
def create_payment_intent():
    """Create Stripe payment intent"""
    data = request.get_json()
    reservation_id = data.get('reservation_id')
    amount = data.get('amount')  # In cents
    
    if not reservation_id or not amount:
        return jsonify({'error': 'Reservation ID and amount required'}), 400
    
    try:
        # Verify reservation exists and belongs to user
        booking = Database.find_one('bookings', {
            '_id': ObjectId(reservation_id),
            'user_id': ObjectId(session['user_id'])
        })
        
        if not booking:
            return jsonify({'error': 'Reservation not found'}), 404
        
        # Create Stripe payment intent
        intent = stripe.PaymentIntent.create(
            amount=int(amount),
            currency='inr',
            metadata={'reservation_id': str(reservation_id)}
        )
        
        return jsonify({
            'clientSecret': intent.client_secret,
            'intentId': intent.id
        }), 200
    except stripe.error.CardError as e:
        return jsonify({'error': f'Card error: {e.user_message}'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@payments_bp.route('/confirm', methods=['POST'])
@login_required
def confirm_payment():
    """Confirm payment and create final booking"""
    data = request.get_json()
    payment_intent_id = data.get('paymentIntentId')
    reservation_id = data.get('reservationId')
    
    if not payment_intent_id or not reservation_id:
        return jsonify({'error': 'Payment intent ID and reservation ID required'}), 400
    
    try:
        # Verify payment intent with Stripe
        intent = stripe.PaymentIntent.retrieve(payment_intent_id)
        
        if intent.status != 'succeeded':
            return jsonify({'error': 'Payment not successful'}), 400
        
        # Get reservation
        booking = Database.find_one('bookings', {
            '_id': ObjectId(reservation_id),
            'user_id': ObjectId(session['user_id'])
        })
        
        if not booking:
            return jsonify({'error': 'Reservation not found'}), 404
        
        # Update booking to completed
        Database.update_one('bookings',
            {'_id': ObjectId(reservation_id)},
            {
                'status': 'completed',
                'payment_status': 'completed',
                'stripe_payment_id': payment_intent_id,
                'booking_confirmed_at': datetime.utcnow()
            }
        )
        
        # Mark seats as booked (no longer reserved)
        for seat_id in booking['seat_ids']:
            Database.update_one('seats',
                {'_id': ObjectId(seat_id)},
                {'status': 'booked', 'booked_by': ObjectId(session['user_id'])}
            )
        
        # Update user statistics
        user = Database.find_one('users', {'_id': ObjectId(session['user_id'])})
        Database.update_one('users',
            {'_id': ObjectId(session['user_id'])},
            {
                'total_bookings': user.get('total_bookings', 0) + 1,
                'total_spent': user.get('total_spent', 0) + booking.get('total_amount', 0)
            }
        )
        
        # TODO: Send confirmation email
        
        return jsonify({
            'message': 'Payment confirmed and booking completed',
            'booking_id': str(reservation_id),
            'booking': {
                '_id': str(booking['_id']),
                'show_id': str(booking['show_id']),
                'seat_ids': [str(s) for s in booking['seat_ids']],
                'total_amount': booking.get('total_amount', 0),
                'booking_date': booking.get('created_at').isoformat() if 'created_at' in booking else None
            }
        }), 200
    except stripe.error.InvalidRequestError as e:
        return jsonify({'error': f'Invalid request: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500
```

---

### Step 1.9: Admin Routes (`app/admin.py`)

```python
from flask import Blueprint, request, jsonify
from bson.objectid import ObjectId
from datetime import datetime
from .models import Database
from .decorators import admin_required

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/movies', methods=['POST'])
@admin_required
def create_movie():
    """Create new movie (Admin only)"""
    data = request.get_json()
    
    required_fields = ['title', 'genre', 'director', 'description']
    if not all(k in data for k in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    movie = {
        'title': data['title'],
        'genre': data['genre'],
        'director': data['director'],
        'description': data['description'],
        'cast': data.get('cast', []),
        'duration': data.get('duration', ''),
        'language': data.get('language', 'Hindi'),
        'image': data.get('image', ''),
        'banner': data.get('banner', ''),
        'price': data.get('price', {'2D': 180, '3D': 280, '4DX': 420}),
        'rating': 0,
        'votes': 0,
        'tags': data.get('tags', []),
        'is_active': True,
    }
    
    movie_id = Database.insert_one('movies', movie)
    
    return jsonify({
        'message': 'Movie created',
        'movie_id': str(movie_id)
    }), 201

@admin_bp.route('/shows', methods=['POST'])
@admin_required
def create_show():
    """Create new show (Admin only)"""
    data = request.get_json()
    
    required_fields = ['movie_id', 'screen_id', 'show_date', 'show_time', 'format']
    if not all(k in data for k in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    show = {
        'movie_id': ObjectId(data['movie_id']),
        'screen_id': ObjectId(data['screen_id']),
        'theater_id': ObjectId(data.get('theater_id')),
        'show_date': data['show_date'],
        'show_time': data['show_time'],
        'format': data['format'],
        'ticket_price': data.get('ticket_price', 200),
        'available_seats': data.get('available_seats', 100),
        'booked_seats': [],
        'status': 'active',
    }
    
    show_id = Database.insert_one('shows', show)
    
    # TODO: Create seats for this show automatically
    # TODO: Send "New Show" notification email to all users
    
    return jsonify({
        'message': 'Show created',
        'show_id': str(show_id)
    }), 201

@admin_bp.route('/analytics', methods=['GET'])
@admin_required
def get_analytics():
    """Get sales analytics"""
    # TODO: Implement comprehensive analytics
    
    bookings = Database.find_many('bookings', {'payment_status': 'completed'})
    
    total_revenue = sum(b.get('total_amount', 0) for b in bookings)
    total_bookings = len(bookings)
    
    return jsonify({
        'total_revenue': total_revenue,
        'total_bookings': total_bookings,
        'average_booking_value': total_revenue / total_bookings if total_bookings > 0 else 0
    }), 200
```

---

## 📋 Entry Point (`main.py`)

```python
from app import create_app
import os

if __name__ == '__main__':
    config_name = os.getenv('FLASK_ENV', 'development')
    app = create_app(config_name)
    app.run(debug=True, port=5000)
```

---

## 🚀 To Get Started:

1. **Update requirements.txt** with all new packages
2. **Create `.env` file** with configuration
3. **Create `app/` directory** and add all modules
4. **Refactor existing `app.py`** into modules
5. **Create database collections** and indexes
6. **Build frontend pages** (HTML/CSS/JS)
7. **Test API endpoints** with Postman or Thunder Client

---

Next: We'll create the frontend pages and JavaScript API client!

