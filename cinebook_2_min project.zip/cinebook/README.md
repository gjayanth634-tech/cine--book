# 🎬 CineBook — Movie Ticket Booking App

> BookMyShow-inspired full-stack movie booking platform

---

## Tech Stack

| Layer    | Technology           |
|----------|----------------------|
| Frontend | HTML5, CSS3, Vanilla JS |
| Backend  | Python Flask         |
| Database | MongoDB (+ in-memory fallback) |

---

## Project Structure

```
cinebook/
├── app.py                  # Flask backend (API routes)
├── requirements.txt
├── templates/
│   └── index.html          # Full SPA frontend
└── static/
    └── js/
        └── app.js          # All frontend logic
```

---

## Features

### 🎭 Movie Experience
- Hero carousel with auto-rotating movie banners
- Movie cards with ratings, genres, tags
- Genre filter tabs (Action, Comedy, Horror, Sci-Fi, etc.)
- Real-time search with dropdown results
- "Now Showing" + "Coming Soon" sections

### 🏛️ Theaters
- Theaters for 10+ Indian cities (Mumbai, Delhi, Bangalore, Chennai, Hyderabad, Kolkata, Pune, Ahmedabad, Jaipur, Lucknow)
- Distance, facilities, and showtime display
- City selector with search

### 🎟️ Booking Flow (4 Steps)
1. **Date & Theater** — Select date (8-day calendar), theater, showtime
2. **Format** — 2D / 3D / 4DX with pricing
3. **Seat Map** — Visual seat picker (Premium + Standard rows), max 8 seats
4. **Payment** — UPI (QR + ID), Card (animated card visual), Wallet (PhonePe/Paytm/GPay)

### 💳 Payment
- **UPI** — Animated QR scanner + UPI ID input + 10-minute countdown timer
- **Card** — Live card preview, card number formatting, CVV
- **Wallet** — PhonePe, Paytm, Google Pay, Amazon Pay

### 🎫 Ticket
- Animated booking confirmation
- Barcode-style ticket with all details
- "Sent to mobile" notification
- Download option

### 👤 User Features
- Animated register → auto-redirect to login
- Login with session management
- Profile page (stats, booking history)
- Dashboard (total bookings, spending, recommended movies)

---

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. (Optional) Start MongoDB
```bash
mongod --dbpath /data/db
```
> App works without MongoDB using in-memory storage!

### 3. Run
```bash
python app.py
```

### 4. Open
```
http://localhost:5000
```

---

## API Endpoints

| Method | Endpoint              | Description          |
|--------|-----------------------|----------------------|
| GET    | `/api/movies`         | All movies           |
| GET    | `/api/movie/<id>`     | Movie details        |
| GET    | `/api/theaters/<city>`| Theaters in city     |
| GET    | `/api/cities`         | All supported cities |
| GET    | `/api/showtimes`      | Available showtimes  |
| GET    | `/api/search?q=`      | Search movies        |
| POST   | `/api/register`       | User registration    |
| POST   | `/api/login`          | User login           |
| POST   | `/api/logout`         | Logout               |
| GET    | `/api/session`        | Check login status   |
| POST   | `/api/book`           | Book tickets         |
| GET    | `/api/bookings`       | User's bookings      |

---

## Demo Credentials
Register any account → Login → Book tickets!

---

## Design
- Dark theme inspired by BookMyShow
- **Bebas Neue** display font for headings
- **Nunito** for body text
- Red/Orange gradient brand color
- Animated loading screen, film strip, hero slides
- Responsive for mobile and desktop
