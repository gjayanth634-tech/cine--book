# CineBook API Reference - Frontend Integration Guide

## Base URL
```
Development:  http://localhost:5000
Production:   https://api.cinebook.com
```

## Response Format
All API responses return JSON:
```json
{
  "data": {},
  "error": null,
  "success": true
}
```

---

## 🔐 Authentication Endpoints

### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210",
  "password": "securePassword123"
}

Response: 201 Created
{
  "message": "User registered successfully",
  "user_id": "507f1f77bcf86cd799439011"
}
```

### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securePassword123"
}

Response: 200 OK
{
  "message": "Login successful",
  "user": {
    "id": "507f1f77bcf86cd799439011",
    "name": "John Doe",
    "email": "john@example.com",
    "is_admin": false
  }
}
```

### Check Session
```http
GET /api/auth/check-session

Response: 200 OK
{
  "authenticated": true
}
```

### Logout
```http
POST /api/auth/logout

Response: 200 OK
{
  "message": "Logged out successfully"
}
```

### Get Profile (Auth Required)
```http
GET /api/auth/profile

Response: 200 OK
{
  "id": "507f1f77bcf86cd799439011",
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210",
  "total_bookings": 5,
  "total_spent": 4500
}
```

---

## 🎬 Movie Endpoints

### Get All Movies
```http
GET /api/movies?page=1&genre=Action&language=Hindi

Query Parameters:
- page: Page number (default: 1)
- genre: Filter by genre
- language: Filter by language

Response: 200 OK
{
  "movies": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "title": "Fighter 2",
      "genre": "Action/Thriller",
      "rating": 8.4,
      "duration": "2h 45m",
      "language": "Hindi",
      "votes": 2100,
      "image": "https://...",
      "banner": "https://...",
      "cast": ["Hrithik Roshan", "Deepika Padukone"],
      "director": "Siddharth Anand",
      "description": "...",
      "price": {
        "2D": 180,
        "3D": 280,
        "4DX": 420
      },
      "tags": ["Blockbuster", "Action"]
    }
  ],
  "page": 1
}
```

### Get Movie Details
```http
GET /api/movies/507f1f77bcf86cd799439011

Response: 200 OK
{
  "_id": "507f1f77bcf86cd799439011",
  "title": "Fighter 2",
  "genre": "Action/Thriller",
  "rating": 8.4,
  "duration": "2h 45m",
  "language": "Hindi",
  "votes": 2100,
  "image": "https://...",
  "banner": "https://...",
  "cast": ["Hrithik Roshan", "Deepika Padukone"],
  "director": "Siddharth Anand",
  "description": "...",
  "price": {
    "2D": 180,
    "3D": 280,
    "4DX": 420
  },
  "tags": ["Blockbuster", "Action"]
}
```

### Get Shows for Movie
```http
GET /api/movies/507f1f77bcf86cd799439011/shows?date=2024-06-01

Query Parameters:
- date: Show date (YYYY-MM-DD format)

Response: 200 OK
{
  "shows": [
    {
      "_id": "507f1f77bcf86cd799439012",
      "movie_id": "507f1f77bcf86cd799439011",
      "show_date": "2024-06-01",
      "show_time": "14:30",
      "format": "2D",
      "ticket_price": 180,
      "available_seats": 45,
      "theater": {
        "name": "PVR ICON Juhu",
        "city": "Mumbai"
      }
    }
  ]
}
```

### Toggle Favorite (Auth Required)
```http
POST /api/movies/507f1f77bcf86cd799439011/favorite

Response: 200 OK
{
  "message": "Movie added to favorites",
  "favorites": ["507f1f77bcf86cd799439011", "507f1f77bcf86cd799439012"]
}
```

### Get Favorites (Auth Required)
```http
GET /api/movies/favorites

Response: 200 OK
{
  "favorites": [
    {
      "_id": "507f1f77bcf86cd799439011",
      "title": "Fighter 2",
      ...
    }
  ]
}
```

---

## 🪑 Seat Selection & Booking

### Get Show Seats & Layout
```http
GET /api/bookings/507f1f77bcf86cd799439012/seats

Response: 200 OK
{
  "show": {
    "_id": "507f1f77bcf86cd799439012",
    "movie_id": "507f1f77bcf86cd799439011",
    "show_date": "2024-06-01",
    "show_time": "14:30",
    "format": "2D",
    "ticket_price": 180
  },
  "seats": [
    {
      "_id": "507f1f77bcf86cd799439013",
      "show_id": "507f1f77bcf86cd799439012",
      "row": "A",
      "column": 1,
      "seat_number": "A1",
      "seat_type": "normal",  // normal, premium, wheelchair
      "status": "available"   // available, booked, reserved
    },
    {
      "_id": "507f1f77bcf86cd799439014",
      "row": "A",
      "column": 2,
      "seat_number": "A2",
      "seat_type": "premium",
      "status": "booked"
    }
  ]
}
```

### Reserve Seats (Temporary Hold - 10 min)
```http
POST /api/bookings/reserve
Content-Type: application/json
Authorization: Cookie (session)

{
  "show_id": "507f1f77bcf86cd799439012",
  "seat_ids": ["507f1f77bcf86cd799439013", "507f1f77bcf86cd799439015"]
}

Response: 200 OK
{
  "reservation_id": "607f1f77bcf86cd799439020",
  "expires_at": "2024-06-01T14:10:00.000Z"
}
```

### Cancel Reservation
```http
DELETE /api/bookings/reserve/607f1f77bcf86cd799439020

Response: 200 OK
{
  "message": "Reservation cancelled"
}
```

---

## 💳 Payment Integration

### Create Payment Intent (Stripe)
```http
POST /api/payments/create-intent
Content-Type: application/json
Authorization: Cookie (session)

{
  "reservation_id": "607f1f77bcf86cd799439020",
  "amount": 36000  // Amount in paise (for 360 INR)
}

Response: 200 OK
{
  "clientSecret": "pi_1234567890_secret_...",
  "intentId": "pi_1234567890"
}
```

### Confirm Payment
```http
POST /api/payments/confirm
Content-Type: application/json
Authorization: Cookie (session)

{
  "paymentIntentId": "pi_1234567890",
  "reservationId": "607f1f77bcf86cd799439020"
}

Response: 200 OK
{
  "message": "Payment confirmed and booking completed",
  "booking_id": "607f1f77bcf86cd799439020",
  "booking": {
    "_id": "607f1f77bcf86cd799439020",
    "show_id": "507f1f77bcf86cd799439012",
    "seat_ids": ["507f1f77bcf86cd799439013", "507f1f77bcf86cd799439015"],
    "total_amount": 360,
    "booking_date": "2024-06-01T14:05:00.000Z"
  }
}
```

---

## 📋 Booking Management

### Get My Bookings (Auth Required)
```http
GET /api/bookings/my-bookings?status=upcoming

Query Parameters:
- status: upcoming, past, cancelled

Response: 200 OK
{
  "bookings": [
    {
      "_id": "607f1f77bcf86cd799439020",
      "user_id": "507f1f77bcf86cd799436011",
      "show_id": "507f1f77bcf86cd799439012",
      "seat_ids": ["507f1f77bcf86cd799439013", "507f1f77bcf86cd799439015"],
      "total_amount": 360,
      "booking_date": "2024-06-01T14:05:00.000Z",
      "show_date": "2024-06-01",
      "show_time": "14:30",
      "payment_status": "completed",
      "booking_status": "active"
    }
  ]
}
```

### Get Specific Booking (Auth Required)
```http
GET /api/bookings/607f1f77bcf86cd799439020

Response: 200 OK
{
  "_id": "607f1f77bcf86cd799439020",
  "user_id": "507f1f77bcf86cd799436011",
  "show_id": "507f1f77bcf86cd799439012",
  "seat_ids": ["507f1f77bcf86cd799439013"],
  "total_amount": 180,
  "booking_date": "2024-06-01T14:05:00.000Z",
  "show_date": "2024-06-01",
  "show_time": "14:30",
  "payment_status": "completed",
  "booking_status": "active",
  "qr_code": "...",
  "email_sent": true
}
```

### Cancel Booking (Auth Required)
```http
POST /api/bookings/607f1f77bcf86cd799439020/cancel

Response: 200 OK
{
  "message": "Booking cancelled successfully",
  "refund_amount": 162,  // 90% of 180
  "cancellation_fee": 18  // 10% of 180
}
```

---

## 🛠️ Admin Endpoints

### Create Movie
```http
POST /api/admin/movies
Content-Type: application/json
Authorization: Cookie (session, Admin required)

{
  "title": "New Movie",
  "genre": "Action",
  "director": "John Doe",
  "description": "Movie description",
  "cast": ["Actor 1", "Actor 2"],
  "duration": "2h 30m",
  "language": "Hindi",
  "image": "https://...",
  "banner": "https://...",
  "price": {
    "2D": 180,
    "3D": 280,
    "4DX": 420
  },
  "tags": ["New Release"]
}

Response: 201 Created
{
  "message": "Movie created",
  "movie_id": "507f1f77bcf86cd799439011"
}
```

### Create Show
```http
POST /api/admin/shows
Content-Type: application/json
Authorization: Cookie (session, Admin required)

{
  "movie_id": "507f1f77bcf86cd799439011",
  "screen_id": "507f1f77bcf86cd799439012",
  "theater_id": "507f1f77bcf86cd799439013",
  "show_date": "2024-06-01",
  "show_time": "14:30",
  "format": "2D",
  "ticket_price": 180,
  "available_seats": 100
}

Response: 201 Created
{
  "message": "Show created",
  "show_id": "507f1f77bcf86cd799439014"
}
```

### Get Analytics
```http
GET /api/admin/analytics

Response: 200 OK
{
  "total_revenue": 45000,
  "total_bookings": 150,
  "average_booking_value": 300
}
```

---

## 🔄 Frontend JavaScript Integration

### Example API Call Pattern
```javascript
// API Client
class CineBookAPI {
  static async call(endpoint, method = 'GET', data = null) {
    const options = {
      method,
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include' // Send cookies for session
    };
    
    if (data) options.body = JSON.stringify(data);
    
    const response = await fetch(`http://localhost:5000${endpoint}`, options);
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'API Error');
    }
    
    return await response.json();
  }
}

// Usage Example
async function getMovies() {
  try {
    const result = await CineBookAPI.call('/api/movies?page=1');
    console.log(result.movies);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

async function loginUser(email, password) {
  try {
    const result = await CineBookAPI.call('/api/auth/login', 'POST', {
      email,
      password
    });
    console.log('Logged in:', result.user);
  } catch (error) {
    console.error('Login failed:', error.message);
  }
}
```

---

## ⚠️ Common Error Responses

### 400 Bad Request
```json
{
  "error": "Missing required fields"
}
```

### 401 Unauthorized
```json
{
  "error": "Unauthorized"
}
```

### 403 Forbidden
```json
{
  "error": "Admin access required"
}
```

### 404 Not Found
```json
{
  "error": "Movie not found"
}
```

### 409 Conflict
```json
{
  "error": "Email already registered"
}
```

### 500 Server Error
```json
{
  "error": "Server error"
}
```

---

## 📌 Notes for Frontend Developer

1. **Session Management:** API uses Flask sessions (cookies). Ensure `credentials: 'include'` in fetch requests.

2. **Error Handling:** Always wrap API calls in try-catch blocks.

3. **Loading States:** Show skeleton loaders while fetching movie grids and seat layouts.

4. **Real-time Updates:** Implement WebSocket for seat availability (optional, can use polling initially).

5. **Stripe Integration:** 
   - Install: `npm install @stripe/js`
   - Use `Stripe.js` for client-side payment processing
   - Test card: `4242 4242 4242 4242` (Exp: Any future date, CVC: Any 3 digits)

6. **Rate Limiting:** Implement client-side throttling for rapid API calls.

7. **CORS:** Backend has CORS enabled for local development. Update for production.

---

*API Documentation v1.0 - Last Updated: May 24, 2026*
