from flask import Flask, render_template, request, jsonify, session, redirect, url_for, abort, make_response
from flask_bcrypt import Bcrypt
from flask_socketio import SocketIO, emit, join_room, leave_room
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime, timedelta
import json
import os

import random
import string
import threading
import qrcode
import pdfkit
from functools import wraps

app = Flask(__name__)
app.secret_key = 'cinebook_secret_key_2024'
bcrypt = Bcrypt(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# MongoDB connection (with fallback to in-memory storage)
USE_MONGO = False
try:
    # Fast-fail connection to prevent startup lag if MongoDB is not running
    client = MongoClient('mongodb://localhost:27017/', serverSelectionTimeoutMS=800)
    client.server_info()
    db = client['cinebook']
    USE_MONGO = True
    print("✅ MongoDB connected")
except:
    print("⚠️ MongoDB not available, using in-memory storage")
    db = None

# In-memory fallback storage
memory_db = {
    'users': [{'id': 'admin', 'name': 'Admin User', 'email': 'admin@cinebook.com', 'phone': '0000000000', 'password': bcrypt.generate_password_hash('admin123').decode('utf-8'), 'is_admin': True, 'tier': 'Platinum', 'wallet': 500.0, 'streak': 5, 'badges': ['Early Adopter', 'VIP'], 'ref_code': 'CINE_ADMIN'}],
    'bookings': [],
    'rentals': [],    # {user_email, movie_id, expiry}
    'favorites': {},
    'reviews': [],    # {movie_id, user_name, rating, comment, date, is_spoiler, likes}
    'watch_parties': {}, # code: {movie_id, creator_email, members: []}
    'locked_seats': {}   # show_id: {seat_id: expiry_timestamp}
}

# ─── DATA ────────────────────────────────────────────────────────────────────

MOVIES = [
    # Now Showing
    {"id": "1", "status": "now_showing", "title": "Singham Again", "genre": "Action/Drama", "rating": 7.8, "duration": "2h 38m", "language": "Hindi", "votes": "25.1K", "image": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=400&fit=crop", "cast": ["Ajay Devgn", "Kareena Kapoor", "Deepika Padukone"], "director": "Rohit Shetty", "description": "The quintessential cop Bajirao Singham is back to take on an international crime syndicate in an epic showdown.", "price": {"2D": 180, "3D": 280, "4DX": 420}, "tags": ["Blockbuster", "Action"], "moods": ["Motivational", "Intense"], "age_rating": "U/A", "ott_price": 149, "accessibility": {"subtitles": ["English", "Hindi"], "audio_desc": True}},
    {"id": "2", "status": "now_showing", "title": "Bhool Bhulaiyaa 3", "genre": "Horror/Comedy", "rating": 8.1, "duration": "2h 35m", "language": "Hindi", "votes": "18.7K", "image": "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&h=400&fit=crop", "cast": ["Kartik Aaryan", "Vidya Balan", "Triptii Dimri"], "director": "Anees Bazmee", "description": "Rooh Baba returns to a haunted havel only to find two Manjulikas. The mystery deepens in this spooktacular sequel.", "price": {"2D": 160, "3D": 250, "4DX": 380}, "tags": ["Superhit", "Comedy"], "moods": ["Funny", "Horror Night"], "age_rating": "U/A", "ott_price": 129, "accessibility": {"subtitles": ["English"], "audio_desc": False}},
    {"id": "4", "status": "now_showing", "title": "Gladiator II", "genre": "Action/History", "rating": 8.5, "duration": "2h 28m", "language": "English/Hindi", "votes": "5.9K", "image": "https://images.unsplash.com/photo-1547826039-bfc35e0f1ea8?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=400&fit=crop", "cast": ["Paul Mescal", "Pedro Pascal", "Denzel Washington"], "director": "Ridley Scott", "description": "Years after witnessing the death of Maximus, Lucius is forced into the Colosseum to fight for the future of Rome.", "price": {"2D": 220, "3D": 350, "4DX": 550}, "tags": ["IMAX", "Legendary"], "moods": ["Epic", "Sad"], "age_rating": "A", "ott_price": 199, "accessibility": {"subtitles": ["English", "Spanish"], "audio_desc": True}},
    {"id": "14", "status": "now_showing", "title": "Moana 2", "genre": "Animation/Adventure", "rating": 8.9, "duration": "1h 40m", "language": "English/Hindi", "votes": "8.2K", "image": "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=1200&h=400&fit=crop", "cast": ["Auli'i Cravalho", "Dwayne Johnson"], "director": "David G. Derrick Jr.", "description": "Moana and Maui reunite for an expansive new voyage alongside a crew of unlikely seafarers.", "price": {"2D": 180, "3D": 280, "4DX": 450}, "tags": ["Family Favorite", "Disney"], "moods": ["Happy", "Adventurous"], "age_rating": "U", "ott_price": 99, "accessibility": {"subtitles": ["Multi"], "audio_desc": True}},

    # Coming Soon
    {"id": "5", "status": "coming_soon", "title": "Pushpa 2: The Rule", "genre": "Action/Crime", "rating": 9.8, "duration": "3h 10m", "language": "Telugu/Kannada/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1533928298208-27ff66555d8d?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&h=400&fit=crop", "cast": ["Allu Arjun", "Rashmika Mandanna", "Fahadh Faasil"], "director": "Sukumar", "description": "Pushpa Raj has established his rule. Now, he must defend his empire against internal threats and the relentless SP Bhanwar Singh Shekhawat.", "price": {"2D": 250, "3D": 400, "4DX": 600}, "tags": ["Dec 5", "Most Anticipated"]},
    {"id": "6", "status": "coming_soon", "title": "UI", "genre": "Sci-Fi/Thriller", "rating": 9.5, "duration": "2h 30m", "language": "Kannada", "votes": "0", "image": "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?w=1200&h=400&fit=crop", "cast": ["Upendra"], "director": "Upendra", "description": "The visionary director Upendra returns with a mind-bending dystopian thriller that challenges the perception of reality.", "price": {"2D": 150, "3D": 250, "4DX": 400}, "tags": ["Uppi Directs", "Mind Bending"]},
    {"id": "7", "status": "coming_soon", "title": "Game Changer", "genre": "Action/Political", "rating": 9.1, "duration": "2h 55m", "language": "Telugu/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1200&h=400&fit=crop", "cast": ["Ram Charan", "Kiara Advani"], "director": "S. Shankar", "description": "An honest IAS officer battles political corruption in this high-octane drama from master filmmaker Shankar.", "price": {"2D": 200, "3D": 300, "4DX": 450}, "tags": ["Jan 2025", "Political Drama"]},
    {"id": "8", "status": "coming_soon", "title": "Max", "genre": "Action/Crime", "rating": 9.4, "duration": "2h 45m", "language": "Kannada", "votes": "0", "image": "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&h=400&fit=crop", "cast": ["Kichcha Sudeepa", "Varalaxmi Sarathkumar"], "director": "Vijay Karthikeyaa", "description": "Sudeepa stars as a high-ranking police official caught in a web of crime and justice in this stylistic actioner.", "price": {"2D": 180, "3D": 280, "4DX": 420}, "tags": ["Kichcha Sudeepa", "Massive"]},
    {"id": "12", "status": "coming_soon", "title": "Chhaava", "genre": "Action/History", "rating": 9.6, "duration": "3h 05m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1533107862482-0e6974b06ec4?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1514539079130-25950c84af65?w=1200&h=400&fit=crop", "cast": ["Vicky Kaushal", "Rashmika Mandanna"], "director": "Laxman Utekar", "description": "The epic saga of Chhatrapati Sambhaji Maharaj, the fearless son of Chhatrapati Shivaji Maharaj, chronicling his valiant struggles and legacy.", "price": {"2D": 190, "3D": 320, "4DX": 480}, "tags": ["Historical Epic", "Feb 2025"]},
    {"id": "15", "status": "coming_soon", "title": "Ramayana: Part 1", "genre": "Epic/Drama", "rating": 9.9, "duration": "3h 15m", "language": "Hindi/Kannada/Telugu", "votes": "0", "image": "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=400&fit=crop", "cast": ["Ranbir Kapoor", "Sai Pallavi", "Yash"], "director": "Nitesh Tiwari", "description": "A cinematic retelling of the greatest epic of all time, chronicling the divine journey of Lord Rama.", "price": {"2D": 300, "3D": 450, "4DX": 700}, "tags": ["Diwali 2026", "Mega Epic"]},
    {"id": "16", "status": "coming_soon", "title": "Animal Park", "genre": "Action/Crime", "rating": 9.7, "duration": "3h 30m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1200&h=400&fit=crop", "cast": ["Ranbir Kapoor"], "director": "Sandeep Reddy Vanga", "description": "The brutal and violent saga of the Singh family continues in the sequel to the massive blockbuster Animal.", "price": {"2D": 220, "3D": 350, "4DX": 550}, "tags": ["2026 Release", "Cult Classic"]},
    {"id": "17", "status": "coming_soon", "title": "Avatar: Fire and Ash", "genre": "Sci-Fi/Adventure", "rating": 9.8, "duration": "3h 05m", "language": "English/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1200&h=400&fit=crop", "cast": ["Sam Worthington", "Zoe Saldana"], "director": "James Cameron", "description": "Jake Sully and Neytiri travel across Pandora where they meet a new clan of Na'vi—the Ash People.", "price": {"2D": 250, "3D": 400, "4DX": 650}, "tags": ["Dec 2025/2026", "IMAX 3D"]},
    {"id": "18", "status": "coming_soon", "title": "L2: Empuraan", "genre": "Action/Crime", "rating": 9.5, "duration": "3h 00m", "language": "Malayalam/Kannada/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1509248961158-e54f6934749c?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1461151304267-38535e770f70?w=1200&h=400&fit=crop", "cast": ["Mohanlal", "Prithviraj Sukumaran"], "director": "Prithviraj Sukumaran", "description": "The high-octane political actioner returns, continuing the story of Stephen Nedumpally and his global empire.", "price": {"2D": 180, "3D": 300, "4DX": 480}, "tags": ["Upcoming", "Pan-India"]},
    {"id": "19", "status": "coming_soon", "title": "Peddi", "genre": "Action/Drama", "rating": 9.2, "duration": "2h 40m", "language": "Telugu", "votes": "0", "image": "https://images.unsplash.com/photo-1533928298208-27ff66555d8d?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=1200&h=400&fit=crop", "cast": ["Nani"], "director": "Srikanth Odela", "description": "A high-octane action drama set in the heart of rural Andhra.", "price": {"2D": 150, "3D": 250, "4DX": 400}, "tags": ["Mass", "Upcoming"]},
    {"id": "20", "status": "now_showing", "title": "Michael", "genre": "Action/Crime", "rating": 7.5, "duration": "2h 35m", "language": "Telugu/Tamil", "votes": "5.1K", "image": "https://images.unsplash.com/photo-1594908651097-4081c7f42654?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=400&fit=crop", "cast": ["Sundeep Kishan", "Vijay Sethupathi"], "director": "Ranjit Jeyakodi", "description": "A young man enters the world of gangsters to find his own identity.", "price": {"2D": 140, "3D": 220, "4DX": 350}, "tags": ["Stylized Action"]},
    {"id": "21", "status": "coming_soon", "title": "Dhurandhar", "genre": "Action/Drama", "rating": 8.9, "duration": "2h 45m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1512149177596-f817c7ef5d4c?w=1200&h=400&fit=crop", "cast": ["Sunny Deol"], "director": "Rajkumar Santoshi", "description": "An epic battle for justice and honor in the modern era.", "price": {"2D": 160, "3D": 280, "4DX": 420}, "tags": ["Powerful"]},
    {"id": "22", "status": "coming_soon", "title": "Dhurandhar The Revenge", "genre": "Action", "rating": 9.0, "duration": "2h 30m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&h=400&fit=crop", "cast": ["Sunny Deol"], "director": "Rajkumar Santoshi", "description": "The saga continues as the ultimate warrior seeks vengeance.", "price": {"2D": 160, "3D": 280, "4DX": 420}, "tags": ["Action Sequel"]},
    {"id": "23", "status": "coming_soon", "title": "KD", "genre": "Action/Drama", "rating": 9.3, "duration": "2h 50m", "language": "Kannada/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=400&fit=crop", "cast": ["Dhruva Sarja"], "director": "Prem", "description": "The vintage war of the 1970s Bangalore underworld returns.", "price": {"2D": 150, "3D": 250, "4DX": 400}, "tags": ["Mass Leader"]},
    {"id": "24", "status": "now_showing", "title": "Karupu", "genre": "Action/Thriller", "rating": 7.1, "duration": "2h 20m", "language": "Tamil", "votes": "1.2K", "image": "https://images.unsplash.com/photo-1584061543329-87a70a8451b6?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=1200&h=400&fit=crop", "cast": ["Arya"], "director": "N. Raghavan", "description": "A dark thriller set in the forest exploring the mysteries of the night.", "price": {"2D": 130, "3D": 200, "4DX": 300}, "tags": ["Mystery"]},
    {"id": "25", "status": "coming_soon", "title": "Udly Stort", "genre": "Comedy/Drama", "rating": 8.5, "duration": "2h 10m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&h=400&fit=crop", "cast": ["Ayushmann Khurrana"], "director": "Hitesh Kewalya", "description": "A quirky short story about life in the small town.", "price": {"2D": 120, "3D": 180}, "tags": ["Quirky"]},
    {"id": "26", "status": "coming_soon", "title": "Veerabhadrudu", "genre": "Action/Epic", "rating": 9.4, "duration": "3h 05m", "language": "Telugu", "votes": "0", "image": "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1200&h=400&fit=crop", "cast": ["Nandamuri Balakrishna"], "director": "Gopichand Malineni", "description": "The roar of the lion returns in this epic action spectacle.", "price": {"2D": 180, "3D": 300, "4DX": 450}, "tags": ["NBK"]},
    {"id": "27", "status": "coming_soon", "title": "Drishyam 3", "genre": "Crime/Thriller", "rating": 9.9, "duration": "2h 45m", "language": "Malayalam/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=1200&h=400&fit=crop", "cast": ["Mohanlal", "Ajay Devgn"], "director": "Jeethu Joseph", "description": "Georgekutty and Vijay Salgaonkar face their biggest challenge yet in the final chapter.", "price": {"2D": 200, "3D": 300, "4DX": 500}, "tags": ["Suspense"]},
    {"id": "28", "status": "coming_soon", "title": "Kirshnavataram Part 1: The Heart", "genre": "Epic/Mythology", "rating": 9.8, "duration": "3h 20m", "language": "Hindi/Telugu", "votes": "0", "image": "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=1200&h=400&fit=crop", "cast": ["Mahesh Babu"], "director": "S.S. Rajamouli", "description": "The beginning of the divine avatar saga.", "price": {"2D": 250, "3D": 400, "4DX": 600}, "tags": ["Rajamouli Magic"]},
    {"id": "29", "status": "coming_soon", "title": "Star Wars: The Mandalorian and Grogu", "genre": "Sci-Fi/Adventure", "rating": 9.7, "duration": "2h 15m", "language": "English/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=1200&h=400&fit=crop", "cast": ["Pedro Pascal"], "director": "Jon Favreau", "description": "The bounty hunter and his small companion embark on a new big-screen adventure.", "price": {"2D": 200, "3D": 350, "4DX": 550}, "tags": ["Star Wars"]},
    {"id": "30", "status": "coming_soon", "title": "Mortal Kombat 2", "genre": "Action/Fantasy", "rating": 9.3, "duration": "2h 10m", "language": "English/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1512149177596-f817c7ef5d4c?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=400&fit=crop", "cast": ["Lewis Tan", "Karl Urban"], "director": "Simon McQuoid", "description": "The tournament for the fate of Earthrealm continues.", "price": {"2D": 180, "3D": 300, "4DX": 480}, "tags": ["Fatality"]},
    {"id": "31", "status": "coming_soon", "title": "The Sheep Detectives", "genre": "Animation/Comedy", "rating": 8.8, "duration": "1h 45m", "language": "English/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1505685296765-3a2736de412f?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&h=400&fit=crop", "cast": ["Voice Cast"], "director": "John Stevenson", "description": "A group of unlikely heroes solve crimes in the farm.", "price": {"2D": 120, "3D": 200}, "tags": ["Kids"]},
    {"id": "32", "status": "coming_soon", "title": "The Devil Wears Prada 2", "genre": "Comedy/Drama", "rating": 9.1, "duration": "2h 05m", "language": "English", "votes": "0", "image": "https://images.unsplash.com/photo-1585647347384-2593bcac5517?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1514539079130-25950c84af65?w=1200&h=400&fit=crop", "cast": ["Meryl Streep", "Anne Hathaway"], "director": "David Frankel", "description": "Miranda Priestly returns to reclaim her fashion empire.", "price": {"2D": 200, "3D": 320}, "tags": ["Fashion"]},
    {"id": "33", "status": "coming_soon", "title": "Hokum", "genre": "Drama/Thriller", "rating": 8.4, "duration": "2h 15m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1461151304267-38535e770f70?w=1200&h=400&fit=crop", "cast": ["Nawazuddin Siddiqui"], "director": "Sudhir Mishra", "description": "A tale of deception and power in the heart of the city.", "price": {"2D": 130, "3D": 220}, "tags": ["Dark Drama"]},
    {"id": "34", "status": "coming_soon", "title": "Project Hasil", "genre": "Action/Sci-Fi", "rating": 8.7, "duration": "2h 40m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1533107862482-0e6974b06ec4?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=1200&h=400&fit=crop", "cast": ["Tiger Shroff"], "director": "Siddharth Anand", "description": "A futuristic soldier on a mission to save the last city.", "price": {"2D": 180, "3D": 300, "4DX": 450}, "tags": ["Future"]},
    {"id": "35", "status": "coming_soon", "title": "Marypati Patni Aur Woh Do", "genre": "Comedy/Romance", "rating": 8.6, "duration": "2h 25m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1512149177596-f817c7ef5d4c?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=1200&h=400&fit=crop", "cast": ["Kartik Aaryan", "Ananya Panday"], "director": "Mudassar Aziz", "description": "The confusion doubles in this hilarious sequel.", "price": {"2D": 150, "3D": 250}, "tags": ["Comedy"]},
    {"id": "36", "status": "coming_soon", "title": "Lonaveena", "genre": "Drama/Romance", "rating": 8.3, "duration": "2h 15m", "language": "Telugu", "votes": "0", "image": "https://images.unsplash.com/photo-1533928298208-27ff66555d8d?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=400&fit=crop", "cast": ["Newcomers"], "director": "Sekhar Kammula", "description": "A heart-touching love story set in a small village.", "price": {"2D": 120, "3D": 180}, "tags": ["Heartfelt"]},
    {"id": "37", "status": "coming_soon", "title": "Bhooth Bangla", "genre": "Horror/Comedy", "rating": 9.2, "duration": "2h 30m", "language": "Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&h=400&fit=crop", "cast": ["Akshay Kumar"], "director": "Priyadarshan", "description": "The legendary duo returns for a spooky laughter riot.", "price": {"2D": 170, "3D": 280, "4DX": 400}, "tags": ["Must Watch"]},
    {"id": "38", "status": "coming_soon", "title": "Raja Shivaji", "genre": "Epic/Biography", "rating": 9.9, "duration": "3h 15m", "language": "Marathi/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1514539079130-25950c84af65?w=1200&h=400&fit=crop", "cast": ["Riteish Deshmukh"], "director": "Riteish Deshmukh", "description": "The grand biography of the legendary Maratha king.", "price": {"2D": 200, "3D": 350, "4DX": 500}, "tags": ["Legend"]},
    {"id": "39", "status": "coming_soon", "title": "The Super Mario Galaxy Movie", "genre": "Animation/Sci-Fi", "rating": 9.6, "duration": "1h 55m", "language": "English/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=1200&h=400&fit=crop", "cast": ["Chris Pratt"], "director": "Aaron Horvath", "description": "Mario takes his adventures to the stars.", "price": {"2D": 150, "3D": 250, "4DX": 400}, "tags": ["Galaxy"]},
    {"id": "40", "status": "coming_soon", "title": "Hopper", "genre": "Action/Adventure", "rating": 8.7, "duration": "2h 10m", "language": "English", "votes": "0", "image": "https://images.unsplash.com/photo-1512149177596-f817c7ef5d4c?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1461151304267-38535e770f70?w=1200&h=400&fit=crop", "cast": ["Tom Holland"], "director": "Doug Liman", "description": "A high-stakes thriller across the rooftops of Europe.", "price": {"2D": 180, "3D": 300, "4DX": 450}, "tags": ["Acrobatic"]},
    {"id": "41", "status": "coming_soon", "title": "Panipuri Prem", "genre": "Romance/Comedy", "rating": 8.4, "duration": "2h 20m", "language": "Marathi/Hindi", "votes": "0", "image": "https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop", "banner": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=1200&h=400&fit=crop", "cast": ["Amey Wagh"], "director": "Aditya Sarpotdar", "description": "A sweet and spicy love story beginning at a panipuri stall.", "price": {"2D": 130, "3D": 200}, "tags": ["Spicy Romance"]},
]

THEATERS = {
    "Mumbai": [
        {"id": "mum1", "name": "PVR ICON Juhu", "address": "Juhu, Mumbai", "facilities": ["Dolby Atmos", "Recliner", "4DX"], "distance": "3.2 km"},
        {"id": "mum2", "name": "INOX R-City Mall", "address": "Ghatkopar West, Mumbai", "facilities": ["IMAX", "3D", "Food Court"], "distance": "7.8 km"},
        {"id": "mum3", "name": "Cinepolis Andheri", "address": "Andheri West, Mumbai", "facilities": ["4K Laser", "Recliner", "Bar"], "distance": "5.1 km"},
        {"id": "mum4", "name": "PVR Kurla", "address": "Phoenix Market City, Kurla", "facilities": ["IMAX", "4DX", "Gold"], "distance": "9.4 km"},
    ],
    "Delhi": [
        {"id": "del1", "name": "PVR Saket Select", "address": "Saket, New Delhi", "facilities": ["IMAX", "4DX", "Gold"], "distance": "4.5 km"},
        {"id": "del2", "name": "INOX Nehru Place", "address": "Nehru Place, New Delhi", "facilities": ["Dolby Atmos", "3D"], "distance": "6.2 km"},
        {"id": "del3", "name": "Cinepolis Rohini", "address": "Rohini, New Delhi", "facilities": ["4K", "Recliner"], "distance": "12.1 km"},
        {"id": "del4", "name": "DT Cinemas Vasant", "address": "Vasant Kunj, New Delhi", "facilities": ["3D", "Food Court"], "distance": "8.9 km"},
    ],
    "Bangalore": [
        {"id": "blr1", "name": "PVR Orion Mall", "address": "Rajajinagar, Bangalore", "facilities": ["IMAX", "4DX", "Gold"], "distance": "5.6 km"},
        {"id": "blr2", "name": "INOX Garuda Mall", "address": "Magrath Road, Bangalore", "facilities": ["Dolby Atmos", "Recliner"], "distance": "3.1 km"},
        {"id": "blr3", "name": "Cinepolis Forum", "address": "Hosur Road, Bangalore", "facilities": ["4K Laser", "Bar"], "distance": "7.4 km"},
        {"id": "blr4", "name": "PVR Vega City", "address": "Bannerghatta Road, Bangalore", "facilities": ["IMAX", "3D"], "distance": "11.2 km"},
    ],
    "Chennai": [
        {"id": "che1", "name": "PVR VR Chennai", "address": "Anna Nagar, Chennai", "facilities": ["4DX", "IMAX"], "distance": "4.2 km"},
        {"id": "che2", "name": "INOX Palazzo", "address": "Nungambakkam, Chennai", "facilities": ["Dolby Atmos", "Gold"], "distance": "6.8 km"},
        {"id": "che3", "name": "Sathyam Cinemas", "address": "Royapettah, Chennai", "facilities": ["4K", "Recliner", "Bar"], "distance": "5.3 km"},
        {"id": "che4", "name": "AGS Cinemas Velachery", "address": "Velachery, Chennai", "facilities": ["3D", "Food Court"], "distance": "9.7 km"},
    ],
    "Hyderabad": [
        {"id": "hyd1", "name": "PVR Inorbit Mall", "address": "Madhapur, Hyderabad", "facilities": ["IMAX", "4DX"], "distance": "3.8 km"},
        {"id": "hyd2", "name": "Cinepolis Nexus Hyderabad", "address": "Kukatpally, Hyderabad", "facilities": ["Dolby", "Recliner"], "distance": "7.2 km"},
        {"id": "hyd3", "name": "INOX GVK One", "address": "Banjara Hills, Hyderabad", "facilities": ["Gold", "4K"], "distance": "5.9 km"},
        {"id": "hyd4", "name": "Asian Cinemas Kompally", "address": "Kompally, Hyderabad", "facilities": ["3D", "4DX"], "distance": "14.1 km"},
    ],
    "Kolkata": [
        {"id": "kol1", "name": "INOX South City", "address": "Prince Anwar Shah Rd, Kolkata", "facilities": ["IMAX", "3D"], "distance": "4.1 km"},
        {"id": "kol2", "name": "PVR Acropolis", "address": "Kasba, Kolkata", "facilities": ["Dolby Atmos", "Gold"], "distance": "7.5 km"},
        {"id": "kol3", "name": "Cinepolis Quest", "address": "Park Circus, Kolkata", "facilities": ["4K", "Recliner"], "distance": "3.6 km"},
    ],
    "Pune": [
        {"id": "pun1", "name": "PVR Pavilion Mall", "address": "Nagar Road, Pune", "facilities": ["IMAX", "4DX", "Gold"], "distance": "5.4 km"},
        {"id": "pun2", "name": "INOX Bund Garden", "address": "Bund Garden, Pune", "facilities": ["Dolby Atmos", "3D"], "distance": "3.9 km"},
        {"id": "pun3", "name": "Cinepolis Amanora", "address": "Hadapsar, Pune", "facilities": ["4K", "Bar"], "distance": "9.2 km"},
    ],
    "Ahmedabad": [
        {"id": "ahm1", "name": "PVR Iscon Mega Mall", "address": "S.G. Highway, Ahmedabad", "facilities": ["IMAX", "3D"], "distance": "6.1 km"},
        {"id": "ahm2", "name": "INOX Alpha One", "address": "Vastrapur, Ahmedabad", "facilities": ["4DX", "Gold"], "distance": "4.8 km"},
        {"id": "ahm3", "name": "Cinepolis Himalaya Mall", "address": "Drive-In Road, Ahmedabad", "facilities": ["Dolby", "Recliner"], "distance": "7.3 km"},
    ],
    "Jaipur": [
        {"id": "jai1", "name": "PVR World Trade Park", "address": "Malviya Nagar, Jaipur", "facilities": ["IMAX", "3D", "Gold"], "distance": "5.7 km"},
        {"id": "jai2", "name": "INOX Crystal Palm", "address": "Raja Park, Jaipur", "facilities": ["4DX", "Recliner"], "distance": "3.4 km"},
    ],
    "Lucknow": [
        {"id": "luc1", "name": "PVR Phoenix Palassio", "address": "Sushant Golf City, Lucknow", "facilities": ["IMAX", "4DX"], "distance": "8.2 km"},
        {"id": "luc2", "name": "INOX Lulu Mall", "address": "Amar Shaheed Path, Lucknow", "facilities": ["Gold", "Dolby"], "distance": "6.5 km"},
    ],
    "Mysore": [
        {"id": "mys1", "name": "PVR Nexus Centre City", "address": "Hyder Ali Road, Mysore", "facilities": ["4K", "Dolby Atmos"], "distance": "2.1 km"},
        {"id": "mys2", "name": "INOX Mall of Mysore", "address": "M.G. Road, Mysore", "facilities": ["3D", "Recliner"], "distance": "3.5 km"},
    ],
    "Mangalore": [
        {"id": "man1", "name": "PVR Forum Fiza Mall", "address": "Pandeshwar, Mangalore", "facilities": ["IMAX", "4DX"], "distance": "1.5 km"},
        {"id": "man2", "name": "Cinepolis City Centre", "address": "K.S. Rao Road, Mangalore", "facilities": ["Dolby", "Recliner"], "distance": "2.8 km"},
    ],
    "Hubli": [
        {"id": "hub1", "name": "Cinepolis Urban Oasis Mall", "address": "Gokul Road, Hubli", "facilities": ["Dolby Atmos", "3D"], "distance": "3.2 km"},
        {"id": "hub2", "name": "PVR Laxmi Pride", "address": "Co-en Road, Hubli", "facilities": ["4K", "Recliner"], "distance": "1.1 km"},
    ],
    "Kochi": [
        {"id": "koc1", "name": "PVR Lulu Mall", "address": "Edapally, Kochi", "facilities": ["IMAX", "4DX", "Gold"], "distance": "4.2 km"},
        {"id": "koc2", "name": "Cinepolis Centre Square", "address": "MG Road, Kochi", "facilities": ["Dolby", "Recliner"], "distance": "2.5 km"},
    ],
    "Indore": [
        {"id": "ind1", "name": "PVR Treasure Island", "address": "MG Road, Indore", "facilities": ["IMAX", "3D"], "distance": "1.8 km"},
        {"id": "ind2", "name": "INOX C21 Mall", "address": "Vijay Nagar, Indore", "facilities": ["Dolby Atmos", "Recliner"], "distance": "5.4 km"},
    ],
    "Chandigarh": [
        {"id": "cha1", "name": "PVR Elante Mall", "address": "Industrial Area Phase 1", "facilities": ["IMAX", "4DX", "Gold"], "distance": "3.6 km"},
        {"id": "cha2", "name": "Cinepolis TDI Mall", "address": "Sector 17, Chandigarh", "facilities": ["Dolby Atmos", "Recliner"], "distance": "2.2 km"},
    ],
    "Patna": [
        {"id": "pat1", "name": "Cinepolis P&M Mall", "address": "Patliputra Colony, Patna", "facilities": ["4K", "Dolby"], "distance": "4.5 km"},
        {"id": "pat2", "name": "PVR City Centre", "address": "Lodipur, Patna", "facilities": ["3D", "Recliner"], "distance": "1.2 km"},
    ],
    "Bhubaneswar": [
        {"id": "bhu1", "name": "INOX Symphony Mall", "address": "Rudrapur, Bhubaneswar", "facilities": ["4K", "Dolby Atmos"], "distance": "6.2 km"},
        {"id": "bhu2", "name": "Cinepolis Esplanade", "address": "Rasulgarh, Bhubaneswar", "facilities": ["IMAX", "Recliner"], "distance": "3.8 km"},
    ],
    "Belgaum": [
        {"id": "bel1", "name": "INOX Nucleus Mall", "address": "Camp, Belgaum", "facilities": ["4K", "Dolby"], "distance": "1.2 km"},
        {"id": "bel2", "name": "Chitra Cinema", "address": "Khade Bazar, Belgaum", "facilities": ["DTS", "Standard"], "distance": "0.5 km"},
    ],
    "Gulbarga": [
        {"id": "gul1", "name": "Miraj Cinemas", "address": "Asian Mall, Gulbarga", "facilities": ["Dolby Atmos", "3D"], "distance": "2.1 km"},
        {"id": "gul2", "name": "Shetty Multiplex", "address": "Sedam Road, Gulbarga", "facilities": ["4K", "Food Court"], "distance": "3.4 km"},
    ],
    "Surat": [
        {"id": "sur1", "name": "PVR VR Surat", "address": "Dumas Road, Surat", "facilities": ["IMAX", "4DX", "Gold"], "distance": "5.5 km"},
        {"id": "sur2", "name": "INOX DR World", "address": "Adajan, Surat", "facilities": ["Dolby", "Recliner"], "distance": "4.2 km"},
    ],
    "Nagpur": [
        {"id": "nag1", "name": "PVR Empress City", "address": "Near Gandhi Sagar Lake, Nagpur", "facilities": ["4DX", "IMAX"], "distance": "2.8 km"},
        {"id": "nag2", "name": "Cinepolis Magneto", "address": "Koradi Road, Nagpur", "facilities": ["Dolby Atmos", "Standard"], "distance": "6.1 km"},
    ],
    "Visakhapatnam": [
        {"id": "viz1", "name": "Cinepolis Varun Beach", "address": "Beach Road, Vizag", "facilities": ["IMAX", "Sea View"], "distance": "1.1 km"},
        {"id": "viz2", "name": "INOX CMR Central", "address": "Maddilapalem, Vizag", "facilities": ["Dolby", "Gold"], "distance": "4.5 km"},
    ],
    "Bhopal": [
        {"id": "bho1", "name": "INOX DB Mall", "address": "Arera Hills, Bhopal", "facilities": ["IMAX", "4DX"], "distance": "3.2 km"},
        {"id": "bho2", "name": "PVR Aura Mall", "address": "Gulmohar Colony, Bhopal", "facilities": ["Dolby Atmos", "Recliner"], "distance": "5.7 km"},
    ],
    "Coimbatore": [
        {"id": "coi1", "name": "The Cinema Brookefields", "address": "Brookebond Road, Coimbatore", "facilities": ["4K", "Dolby"], "distance": "2.4 km"},
        {"id": "coi2", "name": "PVR Prozone Mall", "address": "Sathy Road, Coimbatore", "facilities": ["4DX", "Recliner"], "distance": "7.2 km"},
    ],
    "Vadodara": [
        {"id": "vad1", "name": "Inox Seven Seas", "address": "Fatehgunj, Vadodara", "facilities": ["4K", "Dolby"], "distance": "3.1 km"},
        {"id": "vad2", "name": "PVR Nilamber Triumph", "address": "Vasna-Bhayli, Vadodara", "facilities": ["IMAX", "Gold"], "distance": "6.8 km"},
    ],
    "Davanagere": [
        {"id": "dav1", "name": "PVR SS Ganesh Mall", "address": "PB Road, Davanagere", "facilities": ["4K", "Dolby Atmos"], "distance": "1.8 km"},
        {"id": "dav2", "name": "Mallikarjuna Multiplex", "address": "Dental College Road", "facilities": ["Standard", "DTS"], "distance": "2.5 km"},
    ],
    "Shimoga": [
        {"id": "shi1", "name": "Cinepolis Mall of Shimoga", "address": "Garden Area, Shimoga", "facilities": ["4K", "Dolby Atmos"], "distance": "1.2 km"},
        {"id": "shi2", "name": "Veerabhadreshwara Cinema", "address": "B.H. Road", "facilities": ["Standard"], "distance": "0.8 km"},
    ],
    "Bellary": [
        {"id": "belr1", "name": "Radhika Multiplex", "address": "Main Road, Bellary", "facilities": ["4K", "Dolby Atmos"], "distance": "1.5 km"},
        {"id": "belr2", "name": "Satish Cinema", "address": "Bangalore Road", "facilities": ["Standard"], "distance": "2.2 km"},
    ],
    "Tumkur": [
        {"id": "tum1", "name": "Krishna Cinemas", "address": "Ashoka Road, Tumkur", "facilities": ["Dolby Atmos", "Recliner"], "distance": "1.0 km"},
    ],
    "Ranchi": [
        {"id": "ran1", "name": "PVR Nucleus Mall", "address": "Circular Road, Ranchi", "facilities": ["IMAX", "4DX"], "distance": "2.4 km"},
        {"id": "ran2", "name": "Carnival Cinemas", "address": "JD Hi Street Mall", "facilities": ["Dolby", "3D"], "distance": "3.1 km"},
    ],
    "Guwahati": [
        {"id": "guw1", "name": "PVR City Center", "address": "GS Road, Guwahati", "facilities": ["IMAX", "4DX", "Gold"], "distance": "4.5 km"},
        {"id": "guw2", "name": "Cinepolis Dona Planet", "address": "Guwahati", "facilities": ["Dolby Atmos", "Recliner"], "distance": "3.8 km"},
    ],
    "Vijayawada": [
        {"id": "vij1", "name": "PVR Ripples Mall", "address": "Labbipet, Vijayawada", "facilities": ["4K", "Dolby Atmos"], "distance": "1.2 km"},
        {"id": "vij2", "name": "Cinepolis PVP Square", "address": "MG Road", "facilities": ["IMAX", "Recliner"], "distance": "2.0 km"},
    ],
    "Amritsar": [
        {"id": "amr1", "name": "PVR Nexus Amritsar", "address": "GT Road", "facilities": ["IMAX", "4DX"], "distance": "3.5 km"},
        {"id": "amr2", "name": "Cinepolis Mall of Amritsar", "address": "Amritsar", "facilities": ["Dolby", "Gold"], "distance": "4.2 km"},
    ],
    "Dehradun": [
        {"id": "deh1", "name": "PVR Pacific Mall", "address": "Rajpur Road", "facilities": ["4K", "Dolby Atmos"], "distance": "5.1 km"},
        {"id": "deh2", "name": "INOX Glitz", "address": "Chakrata Road", "facilities": ["3D", "Recliner"], "distance": "2.8 km"},
    ],
    "Jodhpur": [
        {"id": "jod1", "name": "PVR Jodhpur", "address": "Circuit House Road", "facilities": ["4K", "Gold"], "distance": "3.0 km"},
    ],
}

SHOWTIMES = ["10:00 AM", "1:00 PM", "4:00 PM", "7:00 PM", "10:00 PM"]

CONCESSIONS = [
    {"id": "c1", "name": "Large Popcorn Combo", "price": 350, "type": "food", "icon": "🍿"},
    {"id": "c2", "name": "Nachos with Extra Cheese", "price": 220, "type": "food", "icon": "🌮"},
    {"id": "c3", "name": "Coke (Large)", "price": 180, "type": "food", "icon": "🥤"},
    {"id": "p1", "name": "Premium Car Parking", "price": 100, "type": "parking", "icon": "🚗"}
]

# ─── ROUTES ───────────────────────────────────────────────────────────────────

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('is_admin'):
            return jsonify({'success': False, 'message': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return decorated_function


@app.route('/api/admin/movies/<movie_id>', methods=['PUT', 'DELETE'])
@admin_required
def admin_edit_delete_movie(movie_id):
    global MOVIES
    movie = next((m for m in MOVIES if m['id'] == movie_id), None)
    if not movie: return jsonify({'success': False, 'message': 'Movie not found'}), 404
    
    if request.method == 'DELETE':
        MOVIES = [m for m in MOVIES if m['id'] != movie_id]
        return jsonify({'success': True, 'message': 'Movie deleted'})
    
    data = request.json
    movie.update(data)
    return jsonify({'success': True, 'movie': movie})

@app.route('/api/admin/movies', methods=['POST'])
@admin_required
def admin_add_movie():
    data = request.json
    new_movie = {
        "id": str(len(MOVIES) + 1),
        "title": data.get('title'),
        "genre": data.get('genre'),
        "rating": float(data.get('rating', 0)),
        "duration": data.get('duration'),
        "language": data.get('language'),
        "votes": "0",
        "image": "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop",
        "banner": "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=1200&h=400&fit=crop",
        "cast": data.get('cast', []),
        "description": data.get('description'),
        "price": {"2D": 150, "3D": 250, "4DX": 400},
        "tags": ["New"]
    }
    MOVIES.append(new_movie)
    return jsonify({'success': True, 'movie': new_movie})

@app.route('/api/admin/theaters', methods=['POST'])
@admin_required
def admin_add_theater():
    data = request.json
    city = data.get('city')
    if city not in THEATERS: THEATERS[city] = []
    new_theater = {
        "id": "t" + str(random.randint(100, 999)),
        "name": data.get('name'),
        "address": data.get('address'),
        "facilities": data.get('facilities', []),
        "distance": "0.1 km"
    }
    THEATERS[city].append(new_theater)
    return jsonify({'success': True, 'theater': new_theater})

@app.route('/api/bookings/download/<ticket_id>')
def download_pdf_ticket(ticket_id):
    if USE_MONGO:
        booking = db.bookings.find_one({'ticket_id': ticket_id}, {'_id': 0})
    else:
        booking = next((b for b in memory_db['bookings'] if b['ticket_id'] == ticket_id), None)
    
    if not booking: return "Ticket not found", 404
    
    html = render_template('ticket_pdf.html', b=booking)
    pdf = pdfkit.from_string(html, False)
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename=Ticket_{ticket_id}.pdf'
    return response

@app.route('/api/user/referral', methods=['POST'])
def apply_referral():
    if 'user_email' not in session: return jsonify({'success': False}), 401
    ref_code = request.json.get('code')
    # Mock logic: award 50 credits to the user if code is valid
    user = next((u for u in memory_db['users'] if u['email'] == session['user_email']), None)
    if user and ref_code:
        user['wallet'] = user.get('wallet', 0) + 50.0
        return jsonify({'success': True, 'message': 'Referral code applied! You earned 50 credits.'})
    return jsonify({'success': False, 'message': 'Invalid code.'})

@app.route('/api/social/watch-party', methods=['POST'])
def create_watch_party():
    if 'user_email' not in session: return jsonify({'success': False}), 401
    data = request.json
    code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
    memory_db['watch_parties'][code] = {
        'movie_id': data.get('movie_id'),
        'creator': session['user_name'],
        'members': [session['user_email']]
    }
    return jsonify({'success': True, 'code': code})

@app.route('/api/reviews', methods=['GET', 'POST'])
def handle_reviews():
    if request.method == 'POST':
        if 'user_email' not in session: return jsonify({'success': False}), 401
        data = request.json
        # AI Fake Review Detection Mock Logic
        comment = data.get('comment', '').lower()
        spam_keywords = ['buy', 'click', 'http', 'cheap', 'best price']
        is_spam = any(k in comment for k in spam_keywords) or len(comment) < 5
        if is_spam:
            return jsonify({'success': False, 'message': 'AI detected this review as spam or too short.'}), 400
            
        review = {
            'movie_id': data.get('movie_id'),
            'user_name': session['user_name'],
            'rating': data.get('rating'),
            'comment': data.get('comment'),
            'is_spoiler': data.get('is_spoiler', False),
            'likes': 0,
            'date': datetime.now().strftime("%Y-%m-%d")
        }
        memory_db['reviews'].append(review)
        return jsonify({'success': True})
    
    movie_id = request.args.get('movie_id')
    movie_reviews = [r for r in memory_db['reviews'] if r['movie_id'] == movie_id]
    return jsonify(movie_reviews)

@app.route('/api/reviews/vote', methods=['POST'])
def vote_review():
    """Allows users to like/dislike reviews."""
    data = request.json
    for r in memory_db['reviews']:
        if r['movie_id'] == data.get('movie_id') and r['user_name'] == data.get('user_name'):
            r['likes'] += 1 if data.get('vote') == 'up' else -1
            break
    return jsonify({'success': True})

    # In a real app, find by unique review ID

# Real-time Seat Locking via Sockets
@socketio.on('lock_seat')
def handle_seat_lock(data):
    show_id = data['show_id']
    seat_id = data['seat_id']
    # Mark seat as yellow (selected/locked) for 5 minutes
    emit('seat_status_update', {'seat_id': seat_id, 'status': 'locked', 'user': session.get('user_name')}, broadcast=True)

# Watch Party Real-time Rooms
@socketio.on('join_party')
def handle_join_party(data):
    code = data.get('code')
    if code in memory_db['watch_parties']:
        join_room(code)
        emit('party_notification', {'message': f"{session.get('user_name')} has joined the watch party!"}, to=code)

@socketio.on('leave_party')
def handle_leave_party(data):
    code = data.get('code')
    leave_room(code)
    emit('party_notification', {'message': f"{session.get('user_name')} has left the watch party."}, to=code)

@socketio.on('unlock_seat')
def handle_seat_unlock(data):
    show_id = data['show_id']
    seat_id = data['seat_id']
    emit('seat_status_update', {'seat_id': seat_id, 'status': 'available'}, broadcast=True)

@app.route('/api/ott/rent', methods=['POST'])
def rent_movie():
    """OTT Hybrid: Allows users to rent for online watching."""
    if 'user_email' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'}), 401
    
    data = request.json
    movie_id = data.get('movie_id')
    
    # 1. Find the movie and price
    movie = next((m for m in MOVIES if m['id'] == movie_id), None)
    if not movie:
        return jsonify({'success': False, 'message': 'Movie not found'}), 404
    
    price = movie.get('ott_price', 99)
    
    # 2. Find the user and check balance
    if USE_MONGO:
        user = db.users.find_one({'email': session['user_email']})
    else:
        user = next((u for u in memory_db['users'] if u['email'] == session['user_email']), None)
        
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404
        
    if user.get('wallet', 0.0) < price:
        return jsonify({'success': False, 'message': f'Insufficient credits. Need ₹{price}.'}), 400
        
    # 3. Deduct credits and update database/session
    new_balance = user.get('wallet', 0.0) - price
    if USE_MONGO:
        db.users.update_one({'email': session['user_email']}, {'$set': {'wallet': new_balance}})
    else:
        user['wallet'] = new_balance
    session['wallet'] = new_balance

    # 4. Record rental
    rental = {
        'user_email': session['user_email'], 
        'movie_id': movie_id, 
        'movie_title': movie['title'],
        'price_paid': price,
        'expiry': (datetime.now() + timedelta(days=2)).isoformat()
    }
    
    if USE_MONGO:
        db.rentals.insert_one(rental)
    else:
        memory_db['rentals'].append(rental)
        
    return jsonify({'success': True, 'message': f'"{movie["title"]}" rented for 48 hours! ₹{price} deducted.', 'wallet': new_balance})

@app.route('/api/analytics/crowd-prediction/<movie_id>')
def crowd_prediction(movie_id):
    """Predicts crowd levels based on booking density."""
    bookings = [b for b in memory_db['bookings'] if b['movie']['id'] == movie_id]
    count = len(bookings)
    # Heuristic logic
    demand = "High 🔥" if count > 10 else "Moderate ⚡" if count > 5 else "Steady 🧊"
    return jsonify({'movie_id': movie_id, 'demand': demand, 'peak_time': "7:00 PM - 10:00 PM"})

@app.route('/api/ai/summarize-trailer', methods=['POST'])
def summarize_trailer():
    """Mock AI endpoint for generating trailer summaries and sentiment."""
    return jsonify({
        'summary': "This high-octane trailer features pulse-pounding action and deep emotional stakes, suggesting a major character evolution.",
        'detected_emotions': ["Exciting", "Emotional", "Tense"],
        'ai_rating': 8.5
    })

@app.route('/api/social/leaderboard')
def get_leaderboard():
    # Rank users by number of reviews written
    counts = {}
    for r in memory_db['reviews']:
        counts[r['user_name']] = counts.get(r['user_name'], 0) + 1
    leaderboard = sorted([{'name': k, 'points': v * 10} for k, v in counts.items()], key=lambda x: x['points'], reverse=True)
    return jsonify(leaderboard[:5])

@app.route('/api/admin/analytics/revenue')
@admin_required
def get_revenue_analytics():
    """Aggregates revenue by movie title and genre."""
    analytics = {'by_movie': {}, 'by_genre': {}}
    for b in memory_db['bookings']:
        m_title = b['movie']['title']
        m_genre = b['movie']['genre'].split('/')[0]
        total = b['total']
        
        analytics['by_movie'][m_title] = analytics['by_movie'].get(m_title, 0) + total
        analytics['by_genre'][m_genre] = analytics['by_genre'].get(m_genre, 0) + total
    return jsonify(analytics)

@app.route('/api/admin/occupancy/<theater_id>')
@admin_required
def get_occupancy_heatmap(theater_id):
    """Returns real-time seat occupancy for the heatmap."""
    # In a real app, this would query specifically for active shows
    booked_seats = []
    for b in memory_db['bookings']:
        if b['theater']['id'] == theater_id:
            booked_seats.extend(b['seats'])
    return jsonify({'booked': list(set(booked_seats))})

@app.route('/api/bookings/cancel/<ticket_id>', methods=['POST'])
def cancel_booking(ticket_id):
    if 'user_email' not in session: return jsonify({'success': False}), 401
    
    booking = next((b for b in memory_db['bookings'] if b['ticket_id'] == ticket_id), None)
    if not booking: return jsonify({'success': False, 'message': 'Booking not found'}), 404
    
    # Refund to wallet (Automated Refund Management)
    user = next((u for u in memory_db['users'] if u['email'] == session['user_email']), None)
    if user:
        user['wallet'] = user.get('wallet', 0.0) + booking['total']
        session['wallet'] = user['wallet']
        
    memory_db['bookings'].remove(booking)
    return jsonify({'success': True, 'refunded': booking['total']})

def get_dynamic_price(base_price, showtime, user_tier='Silver', date_str=None):
    """
    Implements Dynamic Pricing Engine logic:
    - Surge pricing: +20% for 7PM and 10PM shows.
    - Weekend/Holiday: +15% surge.
    - Loyalty discount: Silver (0%), Gold (10%), Platinum (20%).
    """
    final_price = base_price
    
    # Weekend check
    if date_str:
        dt = datetime.strptime(date_str, "%Y-%m-%d")
        if dt.weekday() >= 5: final_price *= 1.15

    # Surge pricing check
    if showtime in ["7:00 PM", "10:00 PM"]:
        final_price *= 1.2
        
    # Tier discount
    discounts = {'Silver': 1.0, 'Gold': 0.9, 'Platinum': 0.8}
    final_price *= discounts.get(user_tier, 1.0)
    
    return int(final_price)

@app.route('/api/recommendations')
def recommend():
    """Content-based filtering using User Watch History."""
    if 'user_email' not in session: return jsonify(MOVIES[:4])
    
    user_email = session['user_email']
    # Get history
    user_bookings = [b for b in memory_db['bookings'] if b['user_email'] == user_email]
    if not user_bookings: return jsonify(MOVIES[:4])
    
    # Find liked genres from history
    watched_ids = {b['movie']['id'] for b in user_bookings}
    liked_genres = {b['movie']['genre'].split('/')[0] for b in user_bookings}
    
    recs = [m for m in MOVIES if m['id'] not in watched_ids and m['genre'].split('/')[0] in liked_genres]
    
    # Fallback to trending
    return jsonify(recs[:4] if recs else MOVIES[:4])

@app.route('/api/chat', methods=['POST'])
def chatbot():
    """Basic assistant logic for booking."""
    msg = request.json.get('message', '').lower()
    if "funny" in msg:
        return jsonify({'reply': "I recommend 'Bhool Bhulaiyaa 3' for some laughs and spookiness!"})
    if "book" in msg:
        return jsonify({'reply': "I can help! Tell me which movie you're interested in."})
    return jsonify({'reply': "I'm your CineBook assistant. How can I help you today?"})

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/movies')
def get_movies():
    return jsonify(MOVIES)

@app.route('/api/concessions')
def get_concessions():
    return jsonify(CONCESSIONS)

@app.route('/api/movie/<movie_id>')
def get_movie(movie_id):
    movie = next((m for m in MOVIES if m['id'] == movie_id), None)
    user_tier = session.get('user_tier', 'Silver')
    if movie:
        # Calculate dynamic prices for this specific user
        m_copy = movie.copy()
        m_copy['price'] = {
            fmt: get_dynamic_price(p, "4:00 PM", user_tier) # Ref showtime
            for fmt, p in movie['price'].items()}
        return jsonify(m_copy)
    return jsonify({'error': 'Not found'}), 404

@app.route('/api/theaters/<city>')
def get_theaters(city):
    city = city.title()
    theaters = THEATERS.get(city, [])
    return jsonify(theaters)

@app.route('/api/cities')
def get_cities():
    return jsonify(list(THEATERS.keys()))

@app.route('/api/showtimes')
def get_showtimes():
    return jsonify(SHOWTIMES)

@app.route('/api/search')
def search():
    q = request.args.get('q', '').lower()
    mood = request.args.get('mood', '').lower()
    results = [m for m in MOVIES if 
               (q in m['title'].lower() or q in m['genre'].lower()) and 
               (not mood or any(mood in mo.lower() for mo in m.get('moods', [])))
              ]
    return jsonify(results)

@app.route('/api/favorites', methods=['GET', 'POST'])
def handle_favorites():
    if 'user_email' not in session:
        return jsonify({'success': False}), 401
    
    email = session['user_email']
    if request.method == 'POST':
        movie_id = request.json.get('movie_id')
        favs = memory_db['favorites'].get(email, [])
        if movie_id in favs:
            favs.remove(movie_id)
        else:
            favs.append(movie_id)
        memory_db['favorites'][email] = favs
        return jsonify({'success': True, 'favorites': favs})
    
    return jsonify(memory_db['favorites'].get(email, []))

# ─── NOTIFICATION WORKFLOWS ──────────────────────────────────────────────────

def send_mock_email(to_email, subject, body):
    print(f"📧 EMAIL SENT TO {to_email} | SUBJECT: {subject}")
    # In a real app, use Flask-Mail or SendGrid here.

def background_notification_task(task_type, data):
    if task_type == 'booking_conf':
        send_mock_email(data['email'], "Booking Confirmed - CineBook", f"Hi {data['name']}, your ticket ID is {data['ticket_id']}.")
    elif task_type == 'marketing_blast':
        print(f"📢 STARTING MARKETING BLAST FOR: {data['movie_title']}")
        users = memory_db['users'] if not USE_MONGO else list(db.users.find())
        for u in users:
            send_mock_email(u['email'], "New Show Added!", f"Check out {data['movie_title']} now showing!")

@app.route('/api/admin/users')
@admin_required
def get_all_users():
    if USE_MONGO:
        users = list(db.users.find({}, {'password': 0, '_id': 0}))
    else:
        users = [{'name': u['name'], 'email': u['email'], 'phone': u['phone'], 'is_admin': u.get('is_admin', False)} for u in memory_db['users']]
    return jsonify(users)

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    name = data.get('name', '').strip()
    email = data.get('email', '').strip().lower()
    phone = data.get('phone', '').strip()
    password = data.get('password', '')

    if not all([name, email, phone, password]):
        return jsonify({'success': False, 'message': 'All fields are required'}), 400

    if USE_MONGO:
        if db.users.find_one({'email': email}):
            return jsonify({'success': False, 'message': 'Email already registered'}), 400
        if db.users.find_one({'phone': phone}):
            return jsonify({'success': False, 'message': 'Phone number already registered'}), 400
        hashed = bcrypt.generate_password_hash(password).decode('utf-8')
        db.users.insert_one({'name': name, 'email': email, 'phone': phone, 'password': hashed, 'created_at': datetime.now()})
    else:
        if any(u['email'] == email for u in memory_db['users']):
            return jsonify({'success': False, 'message': 'Email already registered'}), 400
        if any(u['phone'] == phone for u in memory_db['users']):
            return jsonify({'success': False, 'message': 'Phone number already registered'}), 400
        hashed = bcrypt.generate_password_hash(password).decode('utf-8')
        memory_db['users'].append({'id': str(len(memory_db['users'])+1), 'name': name, 'email': email, 'phone': phone, 'password': hashed})

    return jsonify({'success': True, 'message': 'Registered successfully!'})

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    identifier = data.get('email', '').strip().lower() # identifier can be email or phone
    password = data.get('password', '')

    if USE_MONGO:
        user = db.users.find_one({'$or': [{'email': identifier}, {'phone': identifier}]})
    else:
        user = next((u for u in memory_db['users'] if u['email'] == identifier or u['phone'] == identifier), None)

    if user and bcrypt.check_password_hash(user['password'], password):
        uid = str(user.get('_id', user.get('id', '')))
        session['user_id'] = uid
        session['user_name'] = user['name']
        session['user_email'] = user['email']
        session['user_phone'] = user['phone']
        session['is_admin'] = user.get('is_admin', False)
        session['user_tier'] = user.get('tier', 'Silver')
        session['wallet'] = user.get('wallet', 0.0)
        session['streak'] = user.get('streak', 0)
        session['badges'] = user.get('badges', [])
        session['ref_code'] = user.get('ref_code', f"CB_{user['name'][:3].upper()}{random.randint(100,999)}")
        return jsonify({'success': True, 'user': {'name': user['name'], 'email': user['email'], 'phone': user['phone'], 'is_admin': session['is_admin'], 'wallet': session['wallet'], 'streak': session['streak'], 'badges': session['badges'], 'ref_code': session['ref_code']}})
    
    return jsonify({'success': False, 'message': 'Invalid email or password'}), 401

@app.route('/api/auth/google', methods=['POST'])
def google_login():
    # Mocking a successful Google OAuth callback
    user = {'name': 'Google Explorer', 'email': 'explorer@gmail.com', 'phone': 'G-SOCIAL', 'is_admin': False}
    session['user_id'] = 'google_user_123'
    session['user_name'] = user['name']
    session['user_email'] = user['email']
    session['user_phone'] = user['phone']
    session['is_admin'] = False
    return jsonify({'success': True, 'user': user})

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/session')
def check_session():
    if 'user_email' in session:
        return jsonify({'logged_in': True, 'user': {'name': session['user_name'], 'email': session['user_email'], 'phone': session['user_phone'], 'is_admin': session.get('is_admin', False)}})
    return jsonify({'logged_in': False})

@app.route('/api/profile/update', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401
    
    data = request.json
    name = data.get('name', '').strip()
    phone = data.get('phone', '').strip()
    new_password = data.get('password', '').strip()

    if not name or not phone:
        return jsonify({'success': False, 'message': 'Name and phone are required'}), 400

    if USE_MONGO:
        update_dict = {'name': name, 'phone': phone}
        if new_password:
            update_dict['password'] = bcrypt.generate_password_hash(new_password).decode('utf-8')
        db.users.update_one({'_id': ObjectId(session['user_id'])}, {'$set': update_dict})
    else:
        user = next((u for u in memory_db['users'] if str(u.get('id', u.get('_id', ''))) == session['user_id']), None)
        if not user:
            return jsonify({'success': False, 'message': 'User not found'}), 404
        user['name'] = name
        user['phone'] = phone
        if new_password:
            user['password'] = bcrypt.generate_password_hash(new_password).decode('utf-8')

    session['user_name'] = name
    session['user_phone'] = phone
    
    return jsonify({
        'success': True, 
        'message': 'Profile updated successfully!',
        'user': {'name': name, 'email': session['user_email'], 'phone': phone, 'is_admin': session.get('is_admin', False)}
    })

@app.route('/api/book', methods=['POST'])
def book_ticket():
    if 'user_email' not in session:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    data = request.json
    ticket_id = 'CB' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    
    booking = {
        'ticket_id': ticket_id,
        'user_email': session['user_email'],
        'user_name': session['user_name'],
        'user_phone': session['user_phone'],
        'movie': data.get('movie'),
        'theater': data.get('theater'),
        'city': data.get('city'),
        'date': data.get('date'),
        'showtime': data.get('showtime'),
        'seats': data.get('seats'),
        'addons': data.get('addons', []),
        'format': data.get('format'),
        'total': data.get('total'),
        'payment_method': data.get('payment_method'),
        'booked_at': datetime.now().isoformat()
    }

    if USE_MONGO:
        db.bookings.insert_one(booking)
        booking.pop('_id', None)  # Remove ObjectId to prevent JSON serialization error
    else:
        user = next((u for u in memory_db['users'] if u['email'] == session['user_email']), None)
        if user:
            # Handle Wallet Deduction
            if data.get('payment_method') == 'wallet':
                if user.get('wallet', 0) < data.get('total'):
                    return jsonify({'success': False, 'message': 'Insufficient wallet balance'}), 400
                user['wallet'] -= data.get('total')
                session['wallet'] = user['wallet']

            # Update Streak & Badges (Memory DB only)
            user['streak'] = user.get('streak', 0) + 1
            session['streak'] = user['streak']
            
            # Award "Horror Fanatic" Badge if movie is Horror
            if "Horror" in data.get('movie', {}).get('genre', '') and "Horror Fanatic" not in user.get('badges', []):
                user.setdefault('badges', []).append("Horror Fanatic")
                session['badges'] = user['badges']
            
            # Award "Weekend Warrior" if booking on Sat/Sun
            if datetime.now().weekday() >= 5 and "Weekend Warrior" not in user.get('badges', []):
                user.setdefault('badges', []).append("Weekend Warrior")

        memory_db['bookings'].append(booking)

    # Trigger async notification
    threading.Thread(target=background_notification_task, args=('booking_conf', {'email': session['user_email'], 'name': session['user_name'], 'ticket_id': ticket_id})).start()

    return jsonify({'success': True, 'ticket_id': ticket_id, 'booking': booking})

@app.route('/api/bookings')
def get_bookings():
    if 'user_email' not in session:
        return jsonify([])
    
    if USE_MONGO:
        bookings = list(db.bookings.find({'user_email': session['user_email']}, {'_id': 0}))
    else:
        bookings = [b for b in memory_db['bookings'] if b['user_email'] == session['user_email']]
    
    return jsonify(bookings)

if __name__ == '__main__':
    socketio.run(app, debug=True, port=5007)
