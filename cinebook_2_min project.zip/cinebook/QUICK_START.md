# 🚀 CineBook Quick Start Guide

## ⚡ 5-Minute Setup

### Step 1: Clone/Update Project
```bash
cd c:\Users\HP\Desktop\cinebook
git init
```

### Step 2: Create Python Virtual Environment
```bash
python -m venv venv
venv\Scripts\activate  # Windows
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Setup Environment Variables
```bash
# Copy .env.example to .env
copy .env.example .env

# Edit .env with your configuration:
# - MongoDB URI
# - Stripe Keys (from https://dashboard.stripe.com/apikeys)
# - Gmail SMTP credentials
```

### Step 5: Verify MongoDB Connection
```bash
# Start MongoDB locally:
# Windows: mongod

# Or use MongoDB Atlas (cloud):
# Get connection string from https://cloud.mongodb.com
```

### Step 6: Run Application
```bash
python main.py

# Server runs at: http://localhost:5000
```

---

## 📋 Development Checklist - Phase 1

### Week 1: Backend Setup & Authentication
- [ ] **Project Structure**
  - [ ] Create `app/` directory with all modules
  - [ ] Update `requirements.txt`
  - [ ] Create `.env` file
  - [ ] Set up `main.py` entry point
  
- [ ] **Database**
  - [ ] Create MongoDB collections:
    - [ ] `users`
    - [ ] `movies`
    - [ ] `theaters`
    - [ ] `screens`
    - [ ] `shows`
    - [ ] `seats`
    - [ ] `bookings`
    - [ ] `transactions`
  - [ ] Create indexes on collections
  
- [ ] **Authentication API**
  - [ ] Register endpoint (`POST /api/auth/register`)
  - [ ] Login endpoint (`POST /api/auth/login`)
  - [ ] Logout endpoint (`POST /api/auth/logout`)
  - [ ] Get profile endpoint (`GET /api/auth/profile`)
  - [ ] Session check endpoint (`GET /api/auth/check-session`)
  - [ ] Test with Postman/Thunder Client

### Week 2: Movies & Bookings API
- [ ] **Movies API**
  - [ ] Get all movies (`GET /api/movies`)
  - [ ] Get movie details (`GET /api/movies/:id`)
  - [ ] Get shows for movie (`GET /api/movies/:id/shows`)
  - [ ] Toggle favorite (`POST /api/movies/:id/favorite`)
  - [ ] Get favorites (`GET /api/movies/favorites`)
  - [ ] Seed database with sample movies

- [ ] **Bookings API**
  - [ ] Get show seats (`GET /api/bookings/:show_id/seats`)
  - [ ] Reserve seats (`POST /api/bookings/reserve`)
  - [ ] Cancel reservation (`DELETE /api/bookings/reserve/:id`)
  - [ ] Get my bookings (`GET /api/bookings/my-bookings`)
  - [ ] Get booking details (`GET /api/bookings/:booking_id`)
  - [ ] Cancel booking (`POST /api/bookings/:booking_id/cancel`)

### Week 3: Payment & Admin
- [ ] **Payment Integration**
  - [ ] Setup Stripe account (test mode)
  - [ ] Create payment intent (`POST /api/payments/create-intent`)
  - [ ] Confirm payment (`POST /api/payments/confirm`)
  - [ ] Test with test card: `4242 4242 4242 4242`

- [ ] **Admin API**
  - [ ] Create movie (`POST /api/admin/movies`)
  - [ ] Create show (`POST /api/admin/shows`)
  - [ ] Get analytics (`GET /api/admin/analytics`)

- [ ] **Background Tasks**
  - [ ] Setup APScheduler
  - [ ] Create email service module
  - [ ] Setup SMTP configuration
  - [ ] (Optional) Test email sending

### Week 4-5: Frontend Pages
- [ ] **Common Components**
  - [ ] Header/Navbar (with login/profile)
  - [ ] Footer
  - [ ] Loading skeleton
  - [ ] Error messages
  - [ ] Modal components

- [ ] **User Pages**
  - [ ] Homepage (movies grid, featured banner)
  - [ ] Movies catalog (with filters)
  - [ ] Movie details page
  - [ ] Booking/Seat selection page
  - [ ] Checkout confirmation
  - [ ] My bookings page
  - [ ] Favorites page

- [ ] **Authentication Pages**
  - [ ] Login page
  - [ ] Register page

- [ ] **Admin Pages**
  - [ ] Admin dashboard (analytics)
  - [ ] Manage movies
  - [ ] Manage shows

---

## 🗄️ Sample Database Setup

### Create Test Movies (MongoDB)
```javascript
db.movies.insertMany([
  {
    "title": "Fighter 2",
    "genre": "Action/Thriller",
    "rating": 8.4,
    "duration": "2h 45m",
    "language": "Hindi",
    "votes": 2100,
    "image": "https://images.unsplash.com/...",
    "banner": "https://images.unsplash.com/...",
    "cast": ["Hrithik Roshan", "Deepika Padukone"],
    "director": "Siddharth Anand",
    "description": "An adrenaline-fueled action saga...",
    "price": {"2D": 180, "3D": 280, "4DX": 420},
    "tags": ["Blockbuster", "Action"],
    "is_active": true
  }
  // Add more movies...
])
```

### Create Test Theater & Screen
```javascript
db.theaters.insertOne({
  "name": "PVR ICON Juhu",
  "city": "Mumbai",
  "address": "Juhu, Mumbai",
  "facilities": ["Dolby Atmos", "Recliner", "4DX"]
})

db.screens.insertOne({
  "theater_id": ObjectId("..."),
  "name": "Screen 1",
  "rows": 10,
  "columns": 10,
  "total_seats": 100
})
```

### Create Test Show
```javascript
db.shows.insertOne({
  "movie_id": ObjectId("..."),
  "screen_id": ObjectId("..."),
  "theater_id": ObjectId("..."),
  "show_date": "2024-06-01",
  "show_time": "14:30",
  "format": "2D",
  "ticket_price": 180,
  "available_seats": 100,
  "booked_seats": [],
  "status": "active"
})
```

---

## 🧪 Testing Endpoints

### Test with cURL or Postman

#### Register User
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "phone": "9876543210",
    "password": "test123"
  }'
```

#### Get Movies
```bash
curl http://localhost:5000/api/movies?page=1
```

#### Get Show Seats
```bash
curl http://localhost:5000/api/bookings/{show_id}/seats
```

---

## 📱 Frontend Development

### Basic Project Structure
```
static/
├── css/
│   ├── style.css          # Global styles
│   ├── responsive.css     # Media queries
│   └── components.css     # Reusable components
├── js/
│   ├── app.js            # Main app logic
│   ├── api.js            # API client
│   ├── auth.js           # Auth logic
│   ├── bookings.js       # Booking engine
│   ├── seat-selector.js  # Seat selection UI
│   └── utils.js          # Utilities
└── images/

templates/
├── index.html
├── movies.html
├── movie-details.html
├── booking.html
├── checkout-confirmation.html
├── my-bookings.html
├── favorites.html
└── auth/
    ├── login.html
    └── register.html
```

### API Client Helper (JavaScript)
```javascript
// static/js/api.js
class CineBookAPI {
  static baseURL = 'http://localhost:5000/api';
  
  static async call(endpoint, method = 'GET', data = null) {
    const options = {
      method,
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include'
    };
    if (data) options.body = JSON.stringify(data);
    
    const response = await fetch(this.baseURL + endpoint, options);
    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error || 'API Error');
    }
    return await response.json();
  }
  
  // Auth methods
  static login(email, password) {
    return this.call('/auth/login', 'POST', { email, password });
  }
  
  static logout() {
    return this.call('/auth/logout', 'POST');
  }
  
  // Movie methods
  static getMovies(page = 1) {
    return this.call(`/movies?page=${page}`);
  }
  
  // ... more methods
}
```

---

## 🔌 External Services Setup

### 1. Stripe Integration
- Sign up: https://dashboard.stripe.com/register
- Get test keys from: https://dashboard.stripe.com/apikeys
- Test card: `4242 4242 4242 4242`
- Add keys to `.env`

### 2. MongoDB Atlas (Cloud)
- Sign up: https://cloud.mongodb.com
- Create cluster
- Get connection string
- Add to `.env` as `MONGO_URI`

### 3. Gmail SMTP
- Enable 2FA on account: https://myaccount.google.com/security
- Generate App Password: https://myaccount.google.com/apppasswords
- Add credentials to `.env`

### 4. (Optional) Deployment Preparation
- **Backend:** Prepare for Render/Railway
- **Frontend:** Prepare for Vercel
- **Database:** MongoDB Atlas (cloud)

---

## 📚 Useful Resources

### Documentation
- [Flask Documentation](https://flask.palletsprojects.com/)
- [MongoDB Documentation](https://docs.mongodb.com/)
- [Stripe API Reference](https://stripe.com/docs/api)
- [MDN Web Docs](https://developer.mozilla.org/)

### Tools
- **API Testing:** [Postman](https://www.postman.com/) or [Thunder Client](https://www.thunderclient.com/)
- **Database GUI:** [MongoDB Compass](https://www.mongodb.com/products/compass)
- **Code Editor:** VS Code with extensions (REST Client, MongoDB, Stripe)

### Payment Testing
- **Test Card Numbers:**
  - Success: `4242 4242 4242 4242`
  - Decline: `4000 0000 0000 0002`
  - 3D Secure: `4000 0025 0000 3155`

---

## 🐛 Common Issues & Solutions

### MongoDB Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:27017

Solution:
1. Ensure MongoDB is running: mongod
2. Or update MONGO_URI to MongoDB Atlas connection
```

### Stripe API Key Error
```
Error: invalid stripe api key

Solution:
1. Check .env file has correct STRIPE_SECRET_KEY
2. Use test keys, not live keys
3. Restart Flask app after updating .env
```

### CORS Error
```
Error: Cross-Origin Request Blocked

Solution:
1. Backend has CORS enabled
2. Ensure credentials: 'include' in fetch requests
3. Check Content-Type header
```

### Session Not Persisting
```
Solution:
1. Set SESSION_COOKIE_SECURE = False in development
2. Ensure cookies are enabled in browser
3. Use credentials: 'include' in fetch requests
```

---

## 📞 Support & Next Steps

### Ready to Start?
1. **Setup:** Follow the 5-minute setup above
2. **Backend:** Start with authentication API (Week 1)
3. **Database:** Populate with test data
4. **Frontend:** Build pages based on API reference
5. **Testing:** Test with Postman before frontend integration

### Need Help?
- Check API_REFERENCE.md for endpoint details
- Review PHASE_1_GUIDE.md for implementation code
- See PROJECT_PROMPT.md for full architecture

---

**Happy Coding! 🎬**

*Last Updated: May 24, 2026*
